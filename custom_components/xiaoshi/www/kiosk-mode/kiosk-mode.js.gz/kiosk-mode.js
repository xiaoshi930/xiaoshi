!function() {
    "use strict";
    function e(e, t, s, n) {
        return new (s || (s = Promise))(function(i, o) {
            function _(e) {
                try {
                    a(n.next(e))
                } catch (e) {
                    o(e)
                }
            }
            function r(e) {
                try {
                    a(n.throw(e))
                } catch (e) {
                    o(e)
                }
            }
            function a(e) {
                var t;
                e.done ? i(e.value) : (t = e.value,
                t instanceof s ? t : new s(function(e) {
                    e(t)
                }
                )).then(_, r)
            }
            a((n = n.apply(e, t || [])).next())
        }
        )
    }
    "function" == typeof SuppressedError && SuppressedError;
    const t = 10
      , s = 10
      , n = (e, n, i={}) => {
        var o;
        const {retries: _=t, delay: r=s, shouldReject: a=!0} = i
          , l = null !== (o = i.rejectMessage) && void 0 !== o ? o : "Could not get the result after {{ retries }} retries";
        return new Promise( (t, s) => {
            let i = 0;
            const o = () => {
                const O = e();
                n(O) ? t(O) : (i++,
                i < _ ? setTimeout(o, r) : a ? s(new Error(l.replace(/\{\{\s*retries\s*\}\}/g, `${_}`))) : t(O))
            }
            ;
            o()
        }
        )
    }
    ;
    function i(e, t, s, n) {
        return new (s || (s = Promise))(function(t, i) {
            function o(e) {
                try {
                    r(n.next(e))
                } catch (e) {
                    i(e)
                }
            }
            function _(e) {
                try {
                    r(n.throw(e))
                } catch (e) {
                    i(e)
                }
            }
            function r(e) {
                var n;
                e.done ? t(e.value) : (n = e.value,
                n instanceof s ? n : new s(function(e) {
                    e(n)
                }
                )).then(o, _)
            }
            r((n = n.apply(e, [])).next())
        }
        )
    }
    "function" == typeof SuppressedError && SuppressedError;
    const o = "$"
      , _ = ":host"
      , r = "invalid selector"
      , a = 10
      , l = 10
      , O = !1
      , E = () => `You can not select a shadowRoot (${o}) of the document.`
      , I = () => `You can not select a shadowRoot (${o}) of a shadowRoot.`
      , A = e => "string" == typeof e
      , c = e => {
        const t = ["retries", "delay", "shouldReject"];
        return s = e,
        "[object Object]" === Object.prototype.toString.call(s) && (0 === Object.keys(e).length || Object.keys(e).every(e => t.includes(e)));
        var s
    }
      , d = (e, t, s) => {
        var n, i, o, _, r, E;
        if (A(e))
            return c(t) ? [document, e, null !== (n = t.retries) && void 0 !== n ? n : a, null !== (i = t.delay) && void 0 !== i ? i : l, null !== (o = t.shouldReject) && void 0 !== o ? o : O] : [document, e, a, l, O];
        if ((e => !!e && (e instanceof Document || e instanceof Element || e instanceof ShadowRoot))(e) && A(t))
            return c(s) ? [e, t, null !== (_ = s.retries) && void 0 !== _ ? _ : a, null !== (r = s.delay) && void 0 !== r ? r : l, null !== (E = s.shouldReject) && void 0 !== E ? E : O] : [e, t, a, l, O];
        throw new TypeError("Wrong parameters have been provided.")
    }
    ;
    function h(e, t) {
        return function(e) {
            return e.split(",").map(e => e.trim())
        }(e).map(e => {
            const s = function(e) {
                return e.split(o).map(e => e.trim())
            }(e);
            return t(s)
        }
        )
    }
    function D(e, t) {
        return `${e} cannot be used with a selector ending in a shadowRoot (${o}).${t ? ` If you want to select a shadowRoot, use ${t} instead.` : ""}`
    }
    function T(e) {
        return e instanceof Promise ? e : Promise.resolve(e)
    }
    function u(e, t) {
        var s, n;
        let i = null;
        const o = e.length;
        for (let r = 0; r < o; r++) {
            if (0 === r)
                if (e[r].length)
                    i = t.querySelector(e[r]);
                else {
                    if (t instanceof Document)
                        throw new SyntaxError(E());
                    if (t instanceof ShadowRoot)
                        throw new SyntaxError(I());
                    i = (null === (s = t.shadowRoot) || void 0 === s ? void 0 : s.querySelector(e[++r])) || null
                }
            else
                i = (null === (n = i.shadowRoot) || void 0 === n ? void 0 : n.querySelector(`${_} ${e[r]}`)) || null;
            if (null === i)
                return null
        }
        return i
    }
    function L(e, t) {
        var s;
        const n = [...e]
          , i = n.pop();
        if (!n.length)
            return t.querySelectorAll(i);
        const o = u(n, t);
        return (null === (s = null == o ? void 0 : o.shadowRoot) || void 0 === s ? void 0 : s.querySelectorAll(`${_} ${i}`)) || null
    }
    function S(e, t) {
        if (1 === e.length && !e[0].length) {
            if (t instanceof Document)
                throw new SyntaxError(E());
            if (t instanceof ShadowRoot)
                throw new SyntaxError(I());
            return t.shadowRoot
        }
        const s = u(e, t);
        return (null == s ? void 0 : s.shadowRoot) || null
    }
    const R = (e, t) => {
        const s = e.querySelectorAll(t);
        if (s.length)
            return s;
        if (e instanceof Element && e.shadowRoot) {
            const s = R(e.shadowRoot, t);
            if (s.length)
                return s
        }
        const n = Array.from(e.querySelectorAll("*"));
        for (const e of n) {
            const s = R(e, t);
            if (s.length)
                return s
        }
        return document.querySelectorAll(r)
    }
      , N = (e, t, s, i, o) => n( () => R(e, t), e => !!e.length, {
        retries: s,
        delay: i,
        shouldReject: o
    });
    function H(e, t, s) {
        return i(this, 0, void 0, function*() {
            return yield function(e, t, s, o, _) {
                return i(this, 0, void 0, function*() {
                    return n( () => function(e, t, s="querySelector", n="shadowRootQuerySelector") {
                        const i = h(t, e => {
                            if (!e[e.length - 1].length)
                                throw new SyntaxError(D(s, n));
                            return e
                        }
                        )
                          , o = i.length;
                        for (let t = 0; t < o; t++) {
                            const s = u(i[t], e);
                            if (s)
                                return s
                        }
                        return null
                    }(e, t, "asyncQuerySelector", "asyncShadowRootQuerySelector"), e => !!e, {
                        retries: s,
                        delay: o,
                        shouldReject: _
                    })
                })
            }(...d(e, t, s))
        })
    }
    function p(e, t, s) {
        return i(this, 0, void 0, function*() {
            return function(e, t, s, o, _) {
                return i(this, 0, void 0, function*() {
                    return n( () => function(e, t, s="querySelectorAll") {
                        const n = h(t, e => {
                            if (!e[e.length - 1].length)
                                throw new SyntaxError(D(s));
                            return e
                        }
                        )
                          , i = n.length;
                        for (let t = 0; t < i; t++) {
                            const s = L(n[t], e);
                            if (null == s ? void 0 : s.length)
                                return s
                        }
                        return document.querySelectorAll(r)
                    }(e, t, "asyncQuerySelectorAll"), e => !!e.length, {
                        retries: s,
                        delay: o,
                        shouldReject: _
                    })
                })
            }(...d(e, t, s))
        })
    }
    function m(e, t, s) {
        return i(this, 0, void 0, function*() {
            return function(e, t, s, _, r) {
                return i(this, 0, void 0, function*() {
                    return n( () => function(e, t, s="shadowRootQuerySelector", n="querySelector") {
                        const i = h(t, e => {
                            if (e.pop().length)
                                throw new SyntaxError(function(e, t) {
                                    return `${e} must be used with a selector ending in a shadowRoot (${o}). If you don't want to select a shadowRoot, use ${t} instead.`
                                }(s, n));
                            return e
                        }
                        )
                          , _ = i.length;
                        for (let t = 0; t < _; t++) {
                            const s = S(i[t], e);
                            if (s)
                                return s
                        }
                        return null
                    }(e, t, "asyncShadowRootQuerySelector", "asyncQuerySelector"), e => !!e, {
                        retries: s,
                        delay: _,
                        shouldReject: r
                    })
                })
            }(...d(e, t, s))
        })
    }
    class f {
        constructor(e, t) {
            e instanceof Node || e instanceof Promise ? (this._element = e,
            this._asyncParams = Object.assign({
                retries: a,
                delay: l,
                shouldReject: O
            }, t || {})) : (this._element = document,
            this._asyncParams = Object.assign({
                retries: a,
                delay: l,
                shouldReject: O
            }, e || {}))
        }
        get element() {
            return T(this._element).then(e => {
                if (e instanceof NodeList) {
                    if (e[0])
                        return e[0];
                    if (!this._asyncParams.shouldReject)
                        return null;
                    throw new SyntaxError('The "element" method can only be called from a NodeList with elements.')
                }
                if (e)
                    return e;
                if (!this._asyncParams.shouldReject)
                    return null;
                throw new SyntaxError('The "element" method can only be called from a non-null element.')
            }
            )
        }
        get $() {
            const e = T(this._element).then(e => {
                if (e instanceof Document || e instanceof ShadowRoot || null === e || e instanceof NodeList && 0 === e.length) {
                    if (!this._asyncParams.shouldReject)
                        return null;
                    throw new SyntaxError('The "$" method can only be called in an element with a ShadowRoot.')
                }
                return e instanceof NodeList ? m(e[0], o, this._asyncParams) : m(e, o, this._asyncParams)
            }
            );
            return new f(e,this._asyncParams)
        }
        get all() {
            return T(this._element).then(e => {
                if (e instanceof NodeList) {
                    if (0 === e.length && this._asyncParams.shouldReject)
                        throw new SyntaxError('The "all" method can only be called in a valid element.');
                    return e
                }
                if (!this._asyncParams.shouldReject)
                    return document.querySelectorAll(r);
                throw new SyntaxError('The "all" method can only be called in a NodeList element.')
            }
            )
        }
        get asyncParams() {
            return this._asyncParams
        }
        eq(e) {
            return i(this, 0, void 0, function*() {
                return T(this._element).then(t => {
                    if (t instanceof NodeList) {
                        if (t[e])
                            return t[e];
                        if (!this._asyncParams.shouldReject)
                            return null;
                        throw new SyntaxError(`Could not get any element at index ${e}.`)
                    }
                    if (!this._asyncParams.shouldReject)
                        return null;
                    throw new SyntaxError('The "eq" method can only be called in a NodeList element.')
                }
                )
            })
        }
        query(e) {
            const t = T(this._element).then(t => {
                if (null === t || t instanceof NodeList && 0 === t.length) {
                    if (!this._asyncParams.shouldReject)
                        return null;
                    throw new SyntaxError('The "query" method can only be called from a defined element.')
                }
                return t instanceof NodeList ? p(t[0], e, this._asyncParams) : p(t, e, this._asyncParams)
            }
            );
            return new f(t,this._asyncParams)
        }
        deepQuery(e) {
            const t = T(this._element).then(t => {
                if (null === t || t instanceof NodeList && 0 === t.length) {
                    if (!this._asyncParams.shouldReject)
                        return null;
                    throw new SyntaxError('The "deepQuery" method can only be called from a defined element.')
                }
                return t instanceof NodeList ? Promise.race(Array.from(t).map(t => N(t, e, this._asyncParams.retries, this._asyncParams.delay, this._asyncParams.shouldReject))) : N(t, e, this._asyncParams.retries, this._asyncParams.delay, this._asyncParams.shouldReject)
            }
            );
            return new f(t,this._asyncParams)
        }
    }
    const G = "$"
      , C = {
        retries: 100,
        delay: 50,
        shouldReject: !1,
        eventThreshold: 450
    };
    var g, v, y, M, b;
    !function(e) {
        e.HOME_ASSISTANT = "HOME_ASSISTANT",
        e.HOME_ASSISTANT_MAIN = "HOME_ASSISTANT_MAIN",
        e.HA_DRAWER = "HA_DRAWER",
        e.HA_SIDEBAR = "HA_SIDEBAR",
        e.PARTIAL_PANEL_RESOLVER = "PARTIAL_PANEL_RESOLVER"
    }(g || (g = {})),
    function(e) {
        e.HA_PANEL_LOVELACE = "HA_PANEL_LOVELACE",
        e.HUI_ROOT = "HUI_ROOT",
        e.HEADER = "HEADER",
        e.HUI_VIEW = "HUI_VIEW"
    }(v || (v = {})),
    function(e) {
        e.HA_MORE_INFO_DIALOG = "HA_MORE_INFO_DIALOG",
        e.HA_DIALOG = "HA_DIALOG",
        e.HA_DIALOG_CONTENT = "HA_DIALOG_CONTENT",
        e.HA_MORE_INFO_DIALOG_INFO = "HA_MORE_INFO_DIALOG_INFO",
        e.HA_DIALOG_MORE_INFO_HISTORY_AND_LOGBOOK = "HA_DIALOG_MORE_INFO_HISTORY_AND_LOGBOOK",
        e.HA_DIALOG_MORE_INFO_SETTINGS = "HA_DIALOG_MORE_INFO_SETTINGS"
    }(y || (y = {})),
    function(e) {
        e.ON_LISTEN = "onListen",
        e.ON_PANEL_LOAD = "onPanelLoad",
        e.ON_LOVELACE_PANEL_LOAD = "onLovelacePanelLoad",
        e.ON_MORE_INFO_DIALOG_OPEN = "onMoreInfoDialogOpen",
        e.ON_HISTORY_AND_LOGBOOK_DIALOG_OPEN = "onHistoryAndLogBookDialogOpen",
        e.ON_SETTINGS_DIALOG_OPEN = "onSettingsDialogOpen"
    }(M || (M = {})),
    function(e) {
        e.HOME_ASSISTANT = "home-assistant",
        e.HOME_ASSISTANT_MAIN = "home-assistant-main",
        e.HA_DRAWER = "ha-drawer",
        e.HA_SIDEBAR = "ha-sidebar",
        e.PARTIAL_PANEL_RESOLVER = "partial-panel-resolver",
        e.HA_PANEL_LOVELACE = "ha-panel-lovelace",
        e.HUI_ROOT = "hui-root",
        e.HEADER = ".header",
        e.HUI_VIEW = "hui-view",
        e.HA_MORE_INFO_DIALOG = "ha-more-info-dialog",
        e.HA_DIALOG = "ha-dialog",
        e.HA_ADAPTATIVE_DIALOG = "ha-adaptive-dialog",
        e.HA_DIALOG_CONTENT = ".content",
        e.HA_MORE_INFO_DIALOG_INFO = "ha-more-info-info",
        e.HA_DIALOG_MORE_INFO_HISTORY_AND_LOGBOOK = "ha-more-info-history-and-logbook",
        e.HA_DIALOG_MORE_INFO_SETTINGS = "ha-more-info-settings"
    }(b || (b = {}));
    const w = {
        [g.HOME_ASSISTANT]: {
            selector: b.HOME_ASSISTANT,
            children: {
                shadowRoot: {
                    selector: G,
                    children: {
                        [g.HOME_ASSISTANT_MAIN]: {
                            selector: b.HOME_ASSISTANT_MAIN,
                            children: {
                                shadowRoot: {
                                    selector: G,
                                    children: {
                                        [g.HA_DRAWER]: {
                                            selector: b.HA_DRAWER,
                                            children: {
                                                [g.HA_SIDEBAR]: {
                                                    selector: b.HA_SIDEBAR,
                                                    children: {
                                                        shadowRoot: {
                                                            selector: G
                                                        }
                                                    }
                                                },
                                                [g.PARTIAL_PANEL_RESOLVER]: {
                                                    selector: b.PARTIAL_PANEL_RESOLVER
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
      , $ = {
        [v.HA_PANEL_LOVELACE]: {
            selector: b.HA_PANEL_LOVELACE,
            children: {
                shadowRoot: {
                    selector: G,
                    children: {
                        [v.HUI_ROOT]: {
                            selector: b.HUI_ROOT,
                            children: {
                                shadowRoot: {
                                    selector: G,
                                    children: {
                                        [v.HEADER]: {
                                            selector: b.HEADER
                                        },
                                        [v.HUI_VIEW]: {
                                            selector: b.HUI_VIEW
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
      , U = {
        shadowRoot: {
            selector: G,
            children: {
                [y.HA_MORE_INFO_DIALOG]: {
                    selector: b.HA_MORE_INFO_DIALOG,
                    children: {
                        shadowRoot: {
                            selector: G,
                            children: {
                                [y.HA_DIALOG]: {
                                    selector: `${b.HA_ADAPTATIVE_DIALOG}, ${b.HA_DIALOG}`,
                                    children: {
                                        [y.HA_DIALOG_CONTENT]: {
                                            selector: b.HA_DIALOG_CONTENT,
                                            children: {
                                                [y.HA_MORE_INFO_DIALOG_INFO]: {
                                                    selector: b.HA_MORE_INFO_DIALOG_INFO
                                                },
                                                [y.HA_DIALOG_MORE_INFO_HISTORY_AND_LOGBOOK]: {
                                                    selector: b.HA_DIALOG_MORE_INFO_HISTORY_AND_LOGBOOK
                                                },
                                                [y.HA_DIALOG_MORE_INFO_SETTINGS]: {
                                                    selector: b.HA_DIALOG_MORE_INFO_SETTINGS
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    };
    "function" == typeof SuppressedError && SuppressedError;
    const P = (e, t, s, n=!1) => Object.entries(t || {}).reduce( (t, i) => {
        const [o,_] = i;
        if (_.selector === G && s)
            return _.children ? Object.assign(Object.assign({}, t), P(e, _.children, s, !0)) : t;
        const r = s ? s.then(t => {
            return t ? H(t, (s = _.selector,
            n ? "$ " + s : s), e) : null;
            var s
        }
        ) : H(_.selector, e);
        return t[o] = {
            element: r,
            children: P(e, _.children, r),
            selector: new f(r,e)
        },
        t
    }
    , {})
      , B = (e, t) => {
        const s = Object.entries(t);
        for (const t of s) {
            if (t[0] === e)
                return t[1];
            {
                const s = B(e, t[1].children);
                if (s)
                    return s
            }
        }
    }
      , F = (e, t) => Object.keys(e).reduce( (e, s) => {
        const n = B(s, t);
        if (n) {
            const {children: t} = n
              , i = function(e, t) {
                var s = {};
                for (var n in e)
                    Object.prototype.hasOwnProperty.call(e, n) && t.indexOf(n) < 0 && (s[n] = e[n]);
                if (null != e && "function" == typeof Object.getOwnPropertySymbols) {
                    var i = 0;
                    for (n = Object.getOwnPropertySymbols(e); i < n.length; i++)
                        t.indexOf(n[i]) < 0 && Object.prototype.propertyIsEnumerable.call(e, n[i]) && (s[n[i]] = e[n[i]])
                }
                return s
            }(n, ["children"]);
            e[s] = Object.assign({}, i)
        }
        return e
    }
    , {});
    class j {
        constructor() {
            this.delegate = document.createDocumentFragment()
        }
        addEventListener(...e) {
            this.delegate.addEventListener(...e)
        }
        dispatchEvent(...e) {
            return this.delegate.dispatchEvent(...e)
        }
        removeEventListener(...e) {
            return this.delegate.removeEventListener(...e)
        }
    }
    let x = class extends j {
        constructor(e={}) {
            super(),
            this._config = Object.assign(Object.assign({}, C), e),
            this._timestaps = {}
        }
        _dispatchEvent(e, t) {
            const s = Date.now();
            this._timestaps[e] && s - this._timestaps[e] < this._config.eventThreshold || (this._timestaps[e] = s,
            this.dispatchEvent(new CustomEvent(e,{
                detail: t
            })))
        }
        _updateDialogElements(e=y.HA_MORE_INFO_DIALOG_INFO) {
            this._dialogTree = P(this._config, U, this._haRootElements.HOME_ASSISTANT.element);
            const t = F(y, this._dialogTree);
            t.HA_DIALOG_CONTENT.element.then(e => {
                this._dialogsContentObserver.disconnect(),
                this._dialogsContentObserver.observe(e, {
                    childList: !0
                })
            }
            ),
            this._haDialogElements = ( (e, t) => [y.HA_MORE_INFO_DIALOG, y.HA_DIALOG, y.HA_DIALOG_CONTENT, t].reduce( (t, s) => (t[s] = e[s],
            t), {}))(t, e);
            const s = {
                [y.HA_MORE_INFO_DIALOG_INFO]: M.ON_MORE_INFO_DIALOG_OPEN,
                [y.HA_DIALOG_MORE_INFO_HISTORY_AND_LOGBOOK]: M.ON_HISTORY_AND_LOGBOOK_DIALOG_OPEN,
                [y.HA_DIALOG_MORE_INFO_SETTINGS]: M.ON_SETTINGS_DIALOG_OPEN
            };
            this._dispatchEvent(s[e], this._haDialogElements)
        }
        _updateRootElements() {
            this._homeAssistantRootTree = P(this._config, w),
            this._haRootElements = F(g, this._homeAssistantRootTree),
            this._haRootElements[g.HOME_ASSISTANT].selector.$.element.then(e => {
                this._dialogsObserver.disconnect(),
                this._dialogsObserver.observe(e, {
                    childList: !0
                })
            }
            ),
            this._haRootElements[g.PARTIAL_PANEL_RESOLVER].element.then(e => {
                this._panelResolverObserver.disconnect(),
                e && this._panelResolverObserver.observe(e, {
                    subtree: !0,
                    childList: !0
                })
            }
            ),
            this._dispatchEvent(M.ON_LISTEN, this._haRootElements),
            this._dispatchEvent(M.ON_PANEL_LOAD, this._haRootElements)
        }
        _updateLovelaceElements() {
            this._homeAssistantResolverTree = P(this._config, $, this._haRootElements[g.HA_DRAWER].element),
            this._haResolverElements = F(v, this._homeAssistantResolverTree),
            this._haResolverElements[v.HA_PANEL_LOVELACE].element.then(e => {
                this._lovelaceObserver.disconnect(),
                e && (this._lovelaceObserver.observe(e.shadowRoot, {
                    childList: !0
                }),
                this._dispatchEvent(M.ON_LOVELACE_PANEL_LOAD, Object.assign(Object.assign({}, this._haRootElements), this._haResolverElements)))
            }
            )
        }
        _watchDialogs(e) {
            e.forEach( ({addedNodes: e}) => {
                e.forEach(e => {
                    e instanceof Element && e.localName === b.HA_MORE_INFO_DIALOG && (this._dialogsChildrenObserver.disconnect(),
                    this._dialogsChildrenObserver.observe(e.shadowRoot, {
                        childList: !0
                    }),
                    this._updateDialogElements())
                }
                )
            }
            )
        }
        _watchDialogsChildren(e) {
            e.forEach( ({addedNodes: e}) => {
                e.forEach(e => {
                    const t = [`${b.HA_DIALOG}`, `${b.HA_ADAPTATIVE_DIALOG}`];
                    e instanceof Element && t.includes(e.localName) && this._updateDialogElements()
                }
                )
            }
            )
        }
        _watchDialogsContent(e) {
            e.forEach( ({addedNodes: e}) => {
                e.forEach(e => {
                    const t = {
                        [b.HA_MORE_INFO_DIALOG_INFO]: y.HA_MORE_INFO_DIALOG_INFO,
                        [b.HA_DIALOG_MORE_INFO_HISTORY_AND_LOGBOOK]: y.HA_DIALOG_MORE_INFO_HISTORY_AND_LOGBOOK,
                        [b.HA_DIALOG_MORE_INFO_SETTINGS]: y.HA_DIALOG_MORE_INFO_SETTINGS
                    };
                    if (e instanceof Element && e.localName && e.localName in t) {
                        const s = e.localName;
                        this._updateDialogElements(t[s])
                    }
                }
                )
            }
            )
        }
        _watchDashboards(e) {
            e.forEach( ({addedNodes: e}) => {
                e.forEach(e => {
                    this._dispatchEvent(M.ON_PANEL_LOAD, this._haRootElements),
                    e instanceof Element && e.localName === b.HA_PANEL_LOVELACE && this._updateLovelaceElements()
                }
                )
            }
            )
        }
        _watchLovelace(e) {
            e.forEach( ({addedNodes: e}) => {
                e.forEach(e => {
                    e instanceof Element && e.localName === b.HUI_ROOT && this._updateLovelaceElements()
                }
                )
            }
            )
        }
        listen() {
            this._watchDialogsBinded = this._watchDialogs.bind(this),
            this._watchDialogsChildrenBinded = this._watchDialogsChildren.bind(this),
            this._watchDialogsContentBinded = this._watchDialogsContent.bind(this),
            this._watchDashboardsBinded = this._watchDashboards.bind(this),
            this._watchLovelaceBinded = this._watchLovelace.bind(this),
            this._dialogsObserver = new MutationObserver(this._watchDialogsBinded),
            this._dialogsChildrenObserver = new MutationObserver(this._watchDialogsChildrenBinded),
            this._dialogsContentObserver = new MutationObserver(this._watchDialogsContentBinded),
            this._panelResolverObserver = new MutationObserver(this._watchDashboardsBinded),
            this._lovelaceObserver = new MutationObserver(this._watchLovelaceBinded),
            this._updateRootElements(),
            this._updateLovelaceElements()
        }
        addEventListener(e, t, s) {
            super.addEventListener(e, t, s)
        }
    }
    ;
    const W = /([A-Z])([a-z0-9_-]+)/g
      , k = e => (Array.isArray(e) ? e : [e]).map(e => {
        if ("string" == typeof e)
            return e;
        const t = Object.entries(e)
          , s = []
          , n = [];
        return t.forEach(e => {
            const [t,i] = e;
            "object" == typeof i ? s.push(`${t}{${k(i)}}`) : !1 === i ? s.push(`${t}{display: none !important}`) : n.push(`${(e => e.replace(W, (e, t, s, n) => {
                const i = t.toLocaleLowerCase();
                return n ? `-${i}${s}` : `--${i}${s}`
            }
            ))(t)}:${i}`)
        }
        ),
        `${s.join("")}${n.join(";")}`
    }
    ).join("")
      , V = (e, t) => `${t}_${e}`
      , K = e => e instanceof ShadowRoot ? e.host.localName : e.localName
      , Y = (e, t) => {
        const s = V(K(e), t);
        return e.querySelector(`#${s}`)
    }
    ;
    let q = class {
        constructor(e={}) {
            var t, s, n;
            this._prefix = null !== (t = e.prefix) && void 0 !== t ? t : "ha-styles-manager",
            this._namespace = null !== (s = e.namespace) && void 0 !== s ? s : "home-assistant-styles-manager",
            this._throwWarnings = null === (n = e.throwWarnings) || void 0 === n || n
        }
        getStyleElement(e) {
            return Y(e, this._prefix)
        }
        addStyle(e, t) {
            ( (e, t, s, n, i) => {
                if (t) {
                    let n = Y(t, s);
                    if (!n) {
                        const e = V(K(t), s);
                        n = document.createElement("style"),
                        n.setAttribute("id", e),
                        t.appendChild(n)
                    }
                    n.innerHTML = "string" == typeof e ? e : k(e)
                } else
                    i && console.warn(`${n}: no element has been provided calling "addStyle"`)
            }
            )(e, t, this._prefix, this._namespace, this._throwWarnings)
        }
        removeStyle(e) {
            ( (e, t, s, n) => {
                if (e) {
                    const i = Y(e, t);
                    i ? i.remove() : n && console.warn(`${s}: no style to remove calling "removeStyle"`)
                } else
                    n && console.warn(`${s}: no element has been provided calling "removeStyle"`)
            }
            )(e, this._prefix, this._namespace, this._throwWarnings)
        }
    }
    ;
    const z = "[home-assistant-javascript-templates]"
      , Q = /^([a-z_]+)\.(\w+)$/;
    var J, X, Z, ee;
    !function(e) {
        e.UNKNOWN = "unknown",
        e.UNAVAILABLE = "unavailable"
    }(J || (J = {})),
    function(e) {
        e.AREA_ID = "area_id",
        e.NAME = "name"
    }(X || (X = {})),
    function(e) {
        e.PANEL_URL = "panel_url",
        e.LANG = "lang"
    }(Z || (Z = {})),
    function(e) {
        e.LOCATION_CHANGED = "location-changed",
        e.TRANSLATIONS_UPDATED = "translations-updated",
        e.POPSTATE = "popstate",
        e.SUBSCRIBE_EVENTS = "subscribe_events",
        e.STATE_CHANGE_EVENT = "state_changed"
    }(ee || (ee = {}));
    const te = "refs"
      , se = e => e.reduce( (e, t) => {
        const [s,n] = t;
        return e[s.replace(Q, "$2")] = n,
        e
    }
    , {})
      , ne = e => e.includes(".")
      , ie = "ref"
      , oe = "value"
      , _e = "toJSON"
      , re = e => `${ie}.${e}`;
    function ae(e, t, s) {
        const n = () => Object.entries(e.hass.areas)
          , i = () => Object.entries(e.hass.devices)
          , o = () => Object.entries(e.hass.entities)
          , _ = new Set
          , r = new Map
          , a = (e, t) => {
            s && console.warn(`${e} ${t} used in a JavaScript template doesn't exist`)
        }
          , l = e => a("Entity", e)
          , O = e => a("Domain", e)
          , E = e => {
            const n = new SyntaxError(e);
            if (t)
                throw n;
            s && console.warn(n)
        }
          , I = t => {
            e.hass.states[t] ? _.add(t) : l(t)
        }
          , A = e => {
            _.add(e)
        }
          , c = (t, s) => {
            const {with_unit: n=!1, rounded: i=!1} = s;
            if (t) {
                const s = t.state
                  , o = t.attributes.unit_of_measurement
                  , _ = Number(i)
                  , r = !1 === i || isNaN(Number(s)) ? s : new Intl.NumberFormat(e.hass.language,{
                    minimumFractionDigits: _,
                    maximumFractionDigits: _
                }).format(Number(s));
                return n && o ? `${r} ${o}` : r
            }
        }
          , d = e => new Proxy(e,{
            get: (e, t) => "state_with_unit" === t ? c(e, {
                rounded: !0,
                with_unit: !0
            }) : e[t]
        });
        return {
            get hass() {
                return e.hass
            },
            states: new Proxy( (t, s={}) => {
                if (ne(t))
                    return I(t),
                    c(e.hass.states[t], s);
                throw SyntaxError(`${z}: states method cannot be used with a domain, use it as an object instead.`)
            }
            ,{
                get(t, s) {
                    if (ne(s))
                        return I(s),
                        d(e.hass.states[s]);
                    const n = Object.entries(e.hass.states).filter( ([e]) => e.startsWith(s));
                    return n.length || O(s),
                    new Proxy(se(n),{
                        get: (e, t) => (I(`${s}.${t}`),
                        d(e[t]))
                    })
                }
            }),
            state_translated(t) {
                if (I(t),
                e.hass.states[t])
                    return e.hass.formatEntityState(e.hass.states[t])
            },
            is_state(t, s) {
                var n;
                return I(t),
                Array.isArray(s) ? s.some(s => {
                    var n;
                    return (null === (n = e.hass.states[t]) || void 0 === n ? void 0 : n.state) === s
                }
                ) : (null === (n = e.hass.states[t]) || void 0 === n ? void 0 : n.state) === s
            },
            state_attr(t, s) {
                var n, i;
                return I(t),
                null === (i = null === (n = e.hass.states[t]) || void 0 === n ? void 0 : n.attributes) || void 0 === i ? void 0 : i[s]
            },
            state_attr_translated(t, s) {
                if (I(t),
                e.hass.states[t])
                    return e.hass.formatEntityAttributeValue(e.hass.states[t], s)
            },
            is_state_attr(e, t, s) {
                return this.state_attr(e, t) === s
            },
            has_value(e) {
                return this.states(e) ? !(this.is_state(e, J.UNKNOWN) || this.is_state(e, J.UNAVAILABLE)) : (l(e),
                !1)
            },
            entities: new Proxy(t => {
                if (void 0 === t)
                    return e.hass.entities;
                if (ne(t))
                    return I(t),
                    e.hass.entities[t];
                const s = o().filter( ([e]) => e.startsWith(t));
                return s.length || O(t),
                new Proxy(se(s),{
                    get: (e, s) => (I(`${t}.${s}`),
                    e[s])
                })
            }
            ,{
                get: (e, t) => e(t)
            }),
            entity_prop(t, s) {
                var n;
                return I(t),
                null === (n = e.hass.entities[t]) || void 0 === n ? void 0 : n[s]
            },
            is_entity_prop(e, t, s) {
                return this.entity_prop(e, t) === s
            },
            devices: new Proxy(t => {
                if (void 0 === t)
                    return e.hass.devices;
                if (ne(t))
                    throw SyntaxError(`${z}: devices method cannot be used with an entity id, you should use a device id instead.`);
                return e.hass.devices[t]
            }
            ,{
                get(t, s) {
                    if (ne(s))
                        throw SyntaxError(`${z}: devices cannot be accesed using an entity id, you should use a device id instead.`);
                    return e.hass.devices[s]
                }
            }),
            device_attr(t, s) {
                var n, i, o;
                if (ne(t)) {
                    I(t);
                    const o = null === (n = e.hass.entities[t]) || void 0 === n ? void 0 : n.device_id;
                    return null === (i = e.hass.devices[o]) || void 0 === i ? void 0 : i[s]
                }
                return null === (o = e.hass.devices[t]) || void 0 === o ? void 0 : o[s]
            },
            is_device_attr(e, t, s) {
                return this.device_attr(e, t) === s
            },
            device_id(t) {
                var s;
                if (ne(t))
                    return I(t),
                    null === (s = e.hass.entities[t]) || void 0 === s ? void 0 : s.device_id;
                const n = i().find(e => e[1].name === t);
                return null == n ? void 0 : n[0]
            },
            device_name(t) {
                var s, n, i, o, _;
                if (ne(t)) {
                    I(t);
                    const o = null === (s = e.hass.entities[t]) || void 0 === s ? void 0 : s.device_id;
                    return null !== (i = null === (n = e.hass.devices[o]) || void 0 === n ? void 0 : n.name) && void 0 !== i ? i : void 0
                }
                return null !== (_ = null === (o = e.hass.devices[t]) || void 0 === o ? void 0 : o.name) && void 0 !== _ ? _ : void 0
            },
            areas: () => n().map( ([,e]) => e.area_id),
            area_id(t) {
                var s, i;
                if (t in e.hass.devices)
                    return this.device_attr(t, X.AREA_ID);
                const o = null === (s = e.hass.entities[t]) || void 0 === s ? void 0 : s.device_id;
                if (o)
                    return this.device_attr(o, X.AREA_ID);
                const _ = n().find( ([,e]) => e.name === t);
                return null === (i = null == _ ? void 0 : _[1]) || void 0 === i ? void 0 : i.area_id
            },
            area_name(t) {
                var s, i;
                let o;
                t in e.hass.devices && (o = this.device_attr(t, X.AREA_ID));
                const _ = null === (s = e.hass.entities[t]) || void 0 === s ? void 0 : s.device_id;
                _ && (o = this.device_attr(_, X.AREA_ID));
                const r = n().find( ([,e]) => e.area_id === t || e.area_id === o);
                return null === (i = null == r ? void 0 : r[1]) || void 0 === i ? void 0 : i.name
            },
            area_entities(e) {
                const t = n().find( ([,t]) => t.area_id === e || t.name === e);
                return t ? o().filter( ([,e]) => e.area_id === t[1].area_id).map( ([e]) => e) : []
            },
            area_devices(e) {
                const t = n().find( ([,t]) => t.area_id === e || t.name === e);
                return t ? i().filter( ([,e]) => e.area_id === t[1].area_id).map( ([,e]) => e.id) : []
            },
            get user_name() {
                return e.hass.user.name
            },
            get user_is_admin() {
                return e.hass.user.is_admin
            },
            get user_is_owner() {
                return e.hass.user.is_owner
            },
            get user_agent() {
                return window.navigator.userAgent
            },
            get tracked() {
                return _
            },
            cleanTracked() {
                _.clear()
            },
            ref(e, t, s=void 0) {
                const n = re(t);
                if (r.has(t))
                    return r.get(t);
                const i = new Proxy({
                    [oe]: s,
                    [_e]() {
                        return this[oe]
                    }
                },{
                    get(e, t, s) {
                        if (t === oe || t === _e)
                            return A(n),
                            Reflect.get(e, t, s);
                        E(`${t} is not a valid ${ie} property. A ${ie} only exposes a "${oe}" property`)
                    },
                    set(t, s, i) {
                        if (s === oe) {
                            const s = t[oe];
                            return t[oe] = i,
                            e({
                                event_type: ee.STATE_CHANGE_EVENT,
                                data: {
                                    entity_id: n,
                                    old_state: {
                                        state: JSON.stringify(s)
                                    },
                                    new_state: {
                                        state: JSON.stringify(i)
                                    }
                                }
                            }),
                            !0
                        }
                        return E(`property "${s}" cannot be set in a ${ie}`),
                        !1
                    }
                });
                return r.set(t, i),
                i
            },
            unref(e, t) {
                const s = re(t);
                r.has(t) ? (r.delete(t),
                e(s)) : E(`${t} is not a ref or it has been unrefed already`)
            },
            refs(e, t, s={}) {
                const n = this.ref
                  , i = this.unref
                  , o = new Proxy(s,{
                    get: (t, s) => n(e, s).value,
                    set: (t, s, i) => (n(e, s).value = i,
                    !0)
                });
                return Object.entries(s).forEach(s => {
                    const [o,_] = s;
                    r.has(o) && i(t, o),
                    n(e, o, _)
                }
                ),
                o
            },
            cleanRefs(e) {
                Array.from(r.keys()).forEach(t => {
                    this.unref(e, t)
                }
                )
            },
            clientSideProxy: new Proxy({},{
                get(t, n) {
                    switch (Object.values(Z).includes(n) && A(n),
                    n) {
                    case Z.PANEL_URL:
                        return window.location.pathname;
                    case Z.LANG:
                        return e.hass.language
                    }
                    s && console.warn(`clientSideProxy should only be used to access these variables: ${Object.values(Z).join(", ")}`)
                }
            })
        }
    }
    class le {
        constructor(e, t) {
            const {throwErrors: s=!1, throwWarnings: n=!0, variables: i={}, refs: o={}, refsVariableName: _=te, autoReturn: r=!0} = t;
            this._throwErrors = s,
            this._throwWarnings = n,
            this._variables = i,
            this._refsVariableName = _,
            this._autoReturn = r,
            this._subscriptions = new Map,
            this._clientSideEntitiesRegExp = new RegExp(`(^|[ \\?(+:\\{\\[><,])(${Object.values(Z).join("|")})($|[ \\?)+:\\}\\]><.,])`,"gm"),
            this._scopped = ae(e, s, n),
            this.refs = o,
            this._watchForPanelUrlChange(),
            this._watchForEntitiesChange(),
            this._watchForLanguageChange()
        }
        _executeRenderingFunctions(e) {
            this._subscriptions.get(e).forEach( (e, t) => {
                e.forEach( (e, s) => {
                    this.trackTemplate(t, s, e)
                }
                )
            }
            )
        }
        _watchForPanelUrlChange() {
            window.addEventListener(ee.LOCATION_CHANGED, () => {
                this._panelUrlWatchCallback()
            }
            ),
            window.addEventListener(ee.POPSTATE, () => {
                this._panelUrlWatchCallback()
            }
            )
        }
        _panelUrlWatchCallback() {
            this._subscriptions.has(Z.PANEL_URL) && this._executeRenderingFunctions(Z.PANEL_URL)
        }
        _watchForEntitiesChange() {
            window.hassConnection.then(e => {
                e.conn.subscribeMessage(e => this._entityWatchCallback(e), {
                    type: ee.SUBSCRIBE_EVENTS,
                    event_type: ee.STATE_CHANGE_EVENT
                })
            }
            )
        }
        _watchForLanguageChange() {
            window.addEventListener(ee.TRANSLATIONS_UPDATED, () => {
                this._subscriptions.has(Z.LANG) && this._executeRenderingFunctions(Z.LANG)
            }
            )
        }
        _entityWatchCallback(e) {
            if (this._subscriptions.size) {
                const t = e.data.entity_id;
                this._subscriptions.has(t) && this._executeRenderingFunctions(t)
            }
        }
        _storeTracked(e, t, s) {
            this._scopped.tracked.forEach(n => {
                const i = [t, s];
                if (this._subscriptions.has(n)) {
                    const s = this._subscriptions.get(n);
                    if (s.has(e)) {
                        const n = s.get(e);
                        n.has(t) || n.set(...i)
                    } else
                        s.set(e, new Map([i]))
                } else
                    this._subscriptions.set(n, new Map([[e, new Map([i])]]))
            }
            )
        }
        _untrackTemplate(e, t) {
            this._subscriptions.forEach( (s, n) => {
                if (s.has(e)) {
                    const i = s.get(e);
                    i.delete(t),
                    0 === i.size && (s.delete(e),
                    0 === s.size && this._subscriptions.delete(n))
                }
            }
            )
        }
        renderTemplate(e, t={}) {
            try {
                const {variables: s={}, refs: n={}} = t
                  , i = new Map(Object.entries(Object.assign(Object.assign({}, this._variables), s)))
                  , o = e.trim().replace(this._clientSideEntitiesRegExp, "$1clientSide.$2$3")
                  , _ = o.includes("return") || !this._autoReturn ? o : `return ${o}`;
                return new Function("hass","states","state_translated","is_state","state_attr","state_attr_translated","is_state_attr","has_value","entities","entity_prop","is_entity_prop","devices","device_attr","is_device_attr","device_id","device_name","areas","area_id","area_name","area_entities","area_devices","user_name","user_is_admin","user_is_owner","user_agent","clientSide","ref","unref",this._refsVariableName,...Array.from(i.keys()),`"use strict"; ${_}`)(this._scopped.hass, this._scopped.states, this._scopped.state_translated.bind(this._scopped), this._scopped.is_state.bind(this._scopped), this._scopped.state_attr.bind(this._scopped), this._scopped.state_attr_translated.bind(this._scopped), this._scopped.is_state_attr.bind(this._scopped), this._scopped.has_value.bind(this._scopped), this._scopped.entities, this._scopped.entity_prop, this._scopped.is_entity_prop.bind(this._scopped), this._scopped.devices, this._scopped.device_attr.bind(this._scopped), this._scopped.is_device_attr.bind(this._scopped), this._scopped.device_id.bind(this._scopped), this._scopped.device_name.bind(this._scopped), this._scopped.areas.bind(this._scopped), this._scopped.area_id.bind(this._scopped), this._scopped.area_name.bind(this._scopped), this._scopped.area_entities.bind(this._scopped), this._scopped.area_devices.bind(this._scopped), this._scopped.user_name, this._scopped.user_is_admin, this._scopped.user_is_owner, this._scopped.user_agent, this._scopped.clientSideProxy, this._scopped.ref.bind(this._scopped, this._entityWatchCallback.bind(this)), this._scopped.unref.bind(this._scopped, this.cleanTracked.bind(this)), this._scopped.refs(this._entityWatchCallback.bind(this), this.cleanTracked.bind(this), n), ...Array.from(i.values()))
            } catch (e) {
                if (this._throwErrors)
                    throw e;
                return void (this._throwWarnings && console.warn(e))
            }
        }
        trackTemplate(e, t, s={}) {
            this._scopped.cleanTracked();
            const n = this.renderTemplate(e, s);
            return this._storeTracked(e, t, s),
            t(n),
            () => this._untrackTemplate(e, t)
        }
        cleanTracked(e) {
            e ? this._subscriptions.has(e) && this._subscriptions.delete(e) : this._subscriptions.clear()
        }
        get variables() {
            return this._variables
        }
        set variables(e) {
            this._variables = e
        }
        get refs() {
            return this._scopped.refs(this._entityWatchCallback.bind(this), this.cleanTracked.bind(this))
        }
        set refs(e) {
            this._scopped.cleanRefs(this.cleanTracked.bind(this)),
            this._scopped.refs(this._entityWatchCallback.bind(this), this.cleanTracked.bind(this), e)
        }
    }
    class Oe {
        constructor(e, t={}) {
            this._renderer = n( () => e.hass, e => !!(e && e.areas && e.devices && e.entities && e.states && e.user), {
                retries: 100,
                delay: 50,
                rejectMessage: "The provided element doesn't contain a proper or initialised hass object"
            }).then( () => new le(e,t))
        }
        getRenderer() {
            return this._renderer
        }
    }
    const Ee = "kiosk-mode";
    var Ie, Ae, ce, de;
    !function(e) {
        e.KIOSK = "kiosk",
        e.HIDE_SIDEBAR = "hide_sidebar",
        e.HIDE_HEADER = "hide_header",
        e.HIDE_ADD_TO_HOME_ASSISTANT = "hide_add_to_home_assistant",
        e.HIDE_OVERFLOW = "hide_overflow",
        e.HIDE_MENU_BUTTON = "hide_menubutton",
        e.HIDE_SETTINGS = "hide_settings",
        e.HIDE_NOTIFICATIONS = "hide_notifications",
        e.HIDE_ACCOUNT = "hide_account",
        e.HIDE_SEARCH = "hide_search",
        e.HIDE_ASSISTANT = "hide_assistant",
        e.HIDE_REFRESH = "hide_refresh",
        e.HIDE_UNUSED_ENTITIES = "hide_unused_entities",
        e.HIDE_RELOAD_RESOURCES = "hide_reload_resources",
        e.HIDE_EDIT_DASHBOARD = "hide_edit_dashboard",
        e.HIDE_DIALOG_HEADER_BREADCRUMB_NAVIGATION = "hide_dialog_header_breadcrumb_navigation",
        e.HIDE_DIALOG_HEADER_ACTION_ITEMS = "hide_dialog_header_action_items",
        e.HIDE_DIALOG_HEADER_HISTORY = "hide_dialog_header_history",
        e.HIDE_DIALOG_HEADER_SETTINGS = "hide_dialog_header_settings",
        e.HIDE_DIALOG_HEADER_OVERFLOW = "hide_dialog_header_overflow",
        e.HIDE_DIALOG_HISTORY = "hide_dialog_history",
        e.HIDE_DIALOG_LOGBOOK = "hide_dialog_logbook",
        e.HIDE_DIALOG_MEDIA_ACTIONS = "hide_dialog_media_actions",
        e.HIDE_DIALOG_UPDATE_ACTIONS = "hide_dialog_update_actions",
        e.HIDE_DIALOG_CAMERA_ACTIONS = "hide_dialog_camera_actions",
        e.HIDE_DIALOG_CLIMATE_ACTIONS = "hide_dialog_climate_actions",
        e.HIDE_DIALOG_CLIMATE_TEMPERATURE_ACTIONS = "hide_dialog_climate_temperature_actions",
        e.HIDE_DIALOG_CLIMATE_SETTINGS_ACTIONS = "hide_dialog_climate_settings_actions",
        e.HIDE_DIALOG_TIMER_ACTIONS = "hide_dialog_timer_actions",
        e.HIDE_DIALOG_LIGHT_ACTIONS = "hide_dialog_light_actions",
        e.HIDE_DIALOG_LIGHT_CONTROL_ACTIONS = "hide_dialog_light_control_actions",
        e.HIDE_DIALOG_LIGHT_COLOR_ACTIONS = "hide_dialog_light_color_actions",
        e.HIDE_DIALOG_LIGHT_SETTINGS_ACTIONS = "hide_dialog_light_settings_actions",
        e.HIDE_DIALOG_HISTORY_SHOW_MORE = "hide_dialog_history_show_more",
        e.HIDE_DIALOG_LOGBOOK_SHOW_MORE = "hide_dialog_logbook_show_more",
        e.BLOCK_OVERFLOW = "block_overflow",
        e.BLOCK_MOUSE = "block_mouse",
        e.BLOCK_CONTEXT_MENU = "block_context_menu"
    }(Ie || (Ie = {})),
    function(e) {
        e.IGNORE_MOBILE_SETTINGS = "ignore_mobile_settings",
        e.IGNORE_DISABLE_KM = "ignore_disable_km"
    }(Ae || (Ae = {})),
    function(e) {
        e.DEBUG = "debug",
        e.DEBUG_TEMPLATE = "debug_template"
    }(ce || (ce = {})),
    function(e) {
        e.CACHE = "cache",
        e.CLEAR_CACHE = "clear_km_cache",
        e.DISABLE_KIOSK_MODE = "disable_km"
    }(de || (de = {}));
    const he = "ui"
      , De = `${he}.common`
      , Te = `${`${he}.panel`}.lovelace`
      , ue = `${Te}.menu`
      , Le = `${`${Te}.editor`}.menu`
      , Se = `${he}.dialogs.more_info_control`;
    var Re;
    !function(e) {
        e.ADD = "ADD",
        e.OVERFLOW = "OVERFLOW",
        e.SEARCH = "SEARCH",
        e.ASSIST = "ASSIST",
        e.REFRESH = "REFRESH",
        e.UNUSED_ENTITIES = "UNUSED_ENTITIES",
        e.RELOAD_RESOURCES = "RELOAD_RESOURCES",
        e.EDIT_DASHBOARD = "EDIT_DASHBOARD",
        e.DIALOG_DISMISS = "DIALOG_DISMISS",
        e.DIALOG_HISTORY = "DIALOG_HISTORY",
        e.DIALOG_SETTINGS = "DIALOG_SETTINGS"
    }(Re || (Re = {}));
    const Ne = Object.freeze({
        [Re.ADD]: `${ue}.add`,
        [Re.OVERFLOW]: `${Le}.open`,
        [Re.SEARCH]: `${ue}.search_home_assistant`,
        [Re.ASSIST]: `${ue}.assist_tooltip`,
        [Re.REFRESH]: `${De}.refresh`,
        [Re.UNUSED_ENTITIES]: `${Te}.unused_entities.title`,
        [Re.RELOAD_RESOURCES]: `${ue}.reload_resources`,
        [Re.EDIT_DASHBOARD]: `${ue}.configure_ui`,
        [Re.DIALOG_HISTORY]: `${Se}.history`,
        [Re.DIALOG_SETTINGS]: `${Se}.settings`,
        [Re.DIALOG_DISMISS]: `${De}.close`
    });
    var He;
    !function(e) {
        e.HOME_ASSISTANT = "home-assistant",
        e.HA_PANEL_LOVELACE = "ha-panel-lovelace",
        e.HUI_VIEW = "hui-view",
        e.MENU_ITEM = "ha-icon-button",
        e.MENU_ITEM_ICON = "mwc-icon-button",
        e.HA_BUTTON = "ha-button",
        e.DROPDOWN = "ha-dropdown",
        e.DROPDOWN_MENU_ITEM = "ha-dropdown-item",
        e.TOOLBAR = ".toolbar",
        e.ACTION_ITEMS = ".action-items",
        e.HA_MORE_INFO_DIALOG = "ha-more-info-dialog",
        e.HA_DIALOG = "ha-adaptive-dialog",
        e.HA_DIALOG_MORE_INFO = "ha-more-info-info",
        e.HA_DIALOG_HISTORY = "ha-more-info-history",
        e.HA_DIALOG_LOGBOOK = "ha-more-info-logbook",
        e.HA_DIALOG_MORE_INFO_CONTENT = "more-info-content",
        e.HA_DIALOG_MORE_INFO_HISTORY_AND_LOGBOOK = "ha-more-info-history-and-logbook",
        e.HA_DIALOG_DEFAULT = "more-info-default",
        e.HA_DIALOG_TIMER = "more-info-timer",
        e.HA_DIALOG_VACUUM = "more-info-vacuum",
        e.HA_DIALOG_CAMERA = "more-info-camera",
        e.HA_DIALOG_SIREN = "more-info-siren",
        e.HA_DIALOG_PERSON = "more-info-person",
        e.HA_DIALOG_MEDIA_PLAYER = "more-info-media_player",
        e.HA_DIALOG_LIGHT = "more-info-light",
        e.HA_DIALOG_UPDATE = "more-info-update",
        e.HA_DIALOG_LOCK = "more-info-lock",
        e.HA_DIALOG_CLIMATE = "more-info-climate",
        e.HA_DIALOG_CLIMATE_CONTROL_SELECT = "ha-more-info-control-select-container",
        e.HA_STATE_CONTROL_CLIMATE_TEMPERATURE = "ha-state-control-climate-temperature",
        e.HA_DIALOG_CLIMATE_TEMPERATURE_BUTTONS = ".buttons",
        e.HA_DIALOG_CLIMATE_CIRCULAR_SLIDER = "ha-control-circular-slider",
        e.HA_DIALOG_CLIMATE_CIRCULAR_SLIDER_INTERACTION = "#interaction",
        e.HA_DIALOG_CLIMATE_CIRCULAR_SLIDER_INTERACTION_SLIDER = 'path[role="slider"]',
        e.HA_DIALOG_CLIMATE_CIRCULAR_SLIDER_INTERACTION_TARGET = ".target",
        e.HA_DIALOG_CLIMATE_CIRCULAR_SLIDER_INTERACTION_TARGET_BORDER = ".target-border",
        e.HA_DIALOG_LIGHT_BRIGHTNESS = "ha-state-control-light-brightness",
        e.HA_DIALOG_LIGHT_CONTROLS = "ha-icon-button-group",
        e.HA_DIALOG_LIGHT_COLORS = "ha-more-info-light-favorite-colors",
        e.HA_DIALOG_LIGHT_SETTINGS = "ha-more-info-control-select-container"
    }(He || (He = {}));
    const pe = /^(.*?)( \([^)]+\))?$/
      , me = "true"
      , fe = /^\s*\[\[\[([\s\S]+)\]\]\]\s*$/
      , Ge = /\{\{[\s\S]*\}\}|\{%[\s\S]*%\}/
      , Ce = "hass-toggle-menu"
      , ge = "MDCDrawer:closed"
      , ve = "resize"
      , ye = e => `km${e.replace(/(?:^|_)([a-z])/g, (e, t) => t.toUpperCase())}`
      , Me = (...e) => {
        const t = new URLSearchParams(window.location.search);
        return e.some(e => t.has(e))
    }
      , be = (e, ...t) => {
        t.forEach(t => window.localStorage.setItem(ye(t), e))
    }
      , we = (...e) => e.some(e => window.localStorage.getItem(ye(e)) === me)
      , $e = (...e) => Object.fromEntries(e.map(e => [e, !1]))
      , Ue = e => e.filter(e => !!e[0]).map(e => e[1])
      , Pe = e => e.trim().replace(pe, "$1").trim()
      , Be = {
        HEADER: {
            "#view": {
                minHeight: "100vh !important",
                KioskHeaderHeight: "0px",
                paddingTop: "calc(var(--kiosk-header-height) + var(--safe-area-inset-top) + var(--view-container-padding-top, 0px)) !important"
            },
            ".header": !1
        },
        SETTINGS: $e("ha-md-list-item.configuration"),
        NOTIFICATIONS: $e("ha-md-list-item.notifications"),
        ACCOUNT: $e("ha-md-list-item.user"),
        LIST_AFTER_SPACER: $e("ha-md-list.after-spacer"),
        MENU_BUTTON: Object.assign(Object.assign({}, $e(":host(:not([expanded])) .menu", ":host([expanded]) .menu ha-icon-button")), {
            ":host([expanded]) .title": {
                marginLeft: "19px"
            }
        }),
        MENU_BUTTON_BURGER: $e("ha-menu-button"),
        MOUSE: {
            "body::after": {
                bottom: 0,
                content: '""',
                cursor: "none",
                display: "block",
                left: 0,
                position: "fixed",
                right: 0,
                top: 0,
                zIndex: 999999
            }
        },
        SIDEBAR: {
            ":host": {
                MdcDrawerWidth: "0px !important",
                KioskSidebarWidth: "0px"
            },
            "partial-panel-resolver": {
                MdcTopAppBarWidth: "100% !important"
            },
            "ha-drawer > ha-sidebar": !1,
            ".header": {
                width: "100% !important"
            }
        },
        ASIDE: $e(".mdc-drawer"),
        OVERFLOW_MENU: $e(`${He.TOOLBAR} > ${He.ACTION_ITEMS} > ${He.DROPDOWN} > ${He.MENU_ITEM}[data-selector="${Re.OVERFLOW}"]`),
        BLOCK_OVERFLOW: {
            [`${He.TOOLBAR} > ${He.ACTION_ITEMS} > ${He.DROPDOWN} > ${He.MENU_ITEM}[data-selector="${Re.OVERFLOW}"]`]: {
                "pointer-events": "none !important"
            }
        },
        ADD_TO_HOME_ASSISTANT: $e(`${He.TOOLBAR} > ${He.ACTION_ITEMS} > ${He.DROPDOWN} > ${He.MENU_ITEM}[data-selector="${Re.ADD}"]`, `${He.TOOLBAR} > ${He.ACTION_ITEMS} > ${He.DROPDOWN} > ${He.DROPDOWN_MENU_ITEM}[data-selector="${Re.ADD}"]`),
        SEARCH: $e(`${He.TOOLBAR} > ${He.ACTION_ITEMS} > ${He.MENU_ITEM}[data-selector="${Re.SEARCH}"]`, `${He.TOOLBAR} > ${He.ACTION_ITEMS} > ${He.DROPDOWN} > ${He.DROPDOWN_MENU_ITEM}[data-selector="${Re.SEARCH}"]`),
        ASSISTANT: $e(`${He.TOOLBAR} > ${He.ACTION_ITEMS} > ${He.MENU_ITEM}[data-selector="${Re.ASSIST}"]`, `${He.TOOLBAR} > ${He.ACTION_ITEMS} > ${He.DROPDOWN} > ${He.DROPDOWN_MENU_ITEM}[data-selector="${Re.ASSIST}"]`),
        REFRESH: $e(`${He.TOOLBAR} > ${He.ACTION_ITEMS} > ${He.DROPDOWN} > ${He.DROPDOWN_MENU_ITEM}[data-selector="${Re.REFRESH}"]`),
        UNUSED_ENTITIES: $e(`${He.TOOLBAR} > ${He.ACTION_ITEMS} > ${He.DROPDOWN} > ${He.DROPDOWN_MENU_ITEM}[data-selector="${Re.UNUSED_ENTITIES}"]`),
        RELOAD_RESOURCES: $e(`${He.TOOLBAR} > ${He.ACTION_ITEMS} > ${He.DROPDOWN} > ${He.DROPDOWN_MENU_ITEM}[data-selector="${Re.RELOAD_RESOURCES}"]`),
        EDIT_DASHBOARD: $e(`${He.TOOLBAR} > ${He.ACTION_ITEMS} > ${He.MENU_ITEM}[data-selector="${Re.EDIT_DASHBOARD}"]`, `${He.TOOLBAR} > ${He.ACTION_ITEMS} > ${He.DROPDOWN} > ${He.DROPDOWN_MENU_ITEM}[data-selector="${Re.EDIT_DASHBOARD}"]`),
        DIALOG_HEADER_BREADCRUMB_NAVIGATION: $e(".title > .breadcrumb"),
        DIALOG_HEADER_HISTORY: $e(`${He.MENU_ITEM}[data-selector="${Re.DIALOG_HISTORY}"]`),
        DIALOG_HEADER_SETTINGS: $e(`${He.MENU_ITEM}[data-selector="${Re.DIALOG_SETTINGS}"]`),
        DIALOG_HEADER_OVERFLOW: $e(`${He.DROPDOWN}`),
        DIALOG_HISTORY: $e(He.HA_DIALOG_HISTORY),
        DIALOG_LOGBOOK: $e(He.HA_DIALOG_LOGBOOK),
        DIALOG_MEDIA_ACTIONS: $e(".bottom-controls > :is(.main-controls, .controls-row)"),
        DIALOG_TIMER_ACTIONS: $e(".actions"),
        DIALOG_UPDATE_ACTIONS: $e(".actions", "ha-md-list:has(+ .actions)", "hr:has(+ .actions)"),
        DIALOG_CAMERA_ACTIONS: $e(".actions"),
        DIALOG_CLIMATE_CONTROL_SELECT: $e(He.HA_DIALOG_CLIMATE_CONTROL_SELECT),
        DIALOG_CLIMATE_TEMPERATURE_BUTTONS: $e(He.HA_DIALOG_CLIMATE_TEMPERATURE_BUTTONS),
        DIALOG_CLIMATE_CIRCULAR_SLIDER_INTERACTION: $e(He.HA_DIALOG_CLIMATE_CIRCULAR_SLIDER_INTERACTION, He.HA_DIALOG_CLIMATE_CIRCULAR_SLIDER_INTERACTION_SLIDER, He.HA_DIALOG_CLIMATE_CIRCULAR_SLIDER_INTERACTION_TARGET_BORDER, He.HA_DIALOG_CLIMATE_CIRCULAR_SLIDER_INTERACTION_TARGET),
        DIALOG_LIGHT_CONTROL_ACTIONS: $e(`.controls > ${He.HA_DIALOG_LIGHT_BRIGHTNESS} + ${He.HA_DIALOG_LIGHT_CONTROLS}`),
        DIALOG_LIGHT_COLOR_ACTIONS: $e(`.controls > ${He.HA_DIALOG_LIGHT_COLORS}`),
        DIALOG_LIGHT_SETTINGS_ACTIONS: $e(`.controls:has(> ${He.HA_DIALOG_LIGHT_BRIGHTNESS}) + div > ${He.HA_DIALOG_LIGHT_SETTINGS}`),
        DIALOG_SHOW_MORE: $e(".header a")
    };
    const Fe = [{
        content: "%c≡ kiosk-mode",
        color: "white",
        background: "#03a9f4"
    }, {
        content: "%cversion 13.0.0"
    }]
      , je = "font-weight: normal; color: inherit;"
      , xe = "font-weight: bold; color: blue;"
      , We = "font-weight: bold; color: red;"
      , ke = "font-weight: bold; color: green;"
      , Ve = "color: #666"
      , Ke = "text-decoration: underline"
      , Ye = Object.values(Ae);
    class qe {
        static logInfo() {
            const e = []
              , t = []
              , s = Fe.length - 1
              , n = {
                "border-color": "#424242",
                "border-style": "solid",
                display: "inline-block",
                "font-family": "monospace",
                "font-size": "12px"
            };
            Fe.forEach( (i, o) => {
                e.push(i.content.padEnd(27)),
                e.push("%c⋮"),
                o !== s && e.push("%c\n");
                let _ = "0 0 0 1px"
                  , r = "0 1px 0 1px";
                0 === o ? (_ = "1px 0 0 1px",
                r = "1px 1px 0 0") : o === s && (_ = "0 0 1px 1px",
                r = "0 1px 1px 0"),
                t.push(k(Object.assign(Object.assign({}, n), {
                    background: i.background || "white",
                    color: i.color || "#424242",
                    padding: 0 === o ? "1px 0px 1px 5px" : "1px 0px 1px 10px",
                    "border-width": _
                }))),
                t.push(k(Object.assign(Object.assign({}, n), {
                    background: i.background || "white",
                    color: i.color || "white",
                    padding: 0 === o ? "1px 5px" : "1px 5px 1px 0px",
                    "border-width": r
                }))),
                o !== s && t.push("")
            }
            ),
            console.info(e.join(""), ...t)
        }
        static debugRawConfig(e, t) {
            console.groupCollapsed(`${Ee} raw config for ${t} panel`),
            console.table(e),
            console.groupEnd()
        }
        static debugFinalConfig(e, t) {
            const s = Object.entries(e).filter( ([e]) => !(e in Ye));
            console.groupCollapsed(`${Ee} final config for ${t} panel`),
            console.table(Object.fromEntries(s)),
            console.groupEnd()
        }
        static debug(e, t, s) {
            console.groupCollapsed(`${Ee} debug`),
            console.info(`Template rendering triggered for option %c${e}%c with the next template:`, xe, je),
            console.info(`%c${t}`, Ve),
            console.info(`The evaluation of this template is: %c${s}`, "boolean" == typeof s ? ke : We),
            "boolean" != typeof s && console.warn("%c⚠️ As this template didn't return a boolean, this option has been set to false", Ke),
            console.groupEnd()
        }
        static debugTemplate(e, t) {
            console.group(`${Ee} template debug`),
            console.info("The template debug has been triggered with the next template:"),
            console.info(`%c${e}`, Ve),
            console.info(`The evaluation of this template is: %c${t}`, "boolean" == typeof t ? ke : We),
            "boolean" != typeof t && console.warn("%c⚠️ This template doesn't return a boolean. It cannot be used as a kiosk-mode option.", Ke),
            console.groupEnd()
        }
    }
    class ze {
        constructor() {
            Me(de.CLEAR_CACHE) && Object.values(Ie).forEach(e => {
                window.localStorage.removeItem(ye(e))
            }
            ),
            this.panelOptions = new Map,
            this.styleManager = new q({
                prefix: "kiosk_mode",
                throwWarnings: !1
            });
            const t = new x;
            t.addEventListener(M.ON_LOVELACE_PANEL_LOAD, t => e(this, void 0, void 0, function*() {
                var e, s;
                this.HAElements = t.detail;
                const {HOME_ASSISTANT: i, HOME_ASSISTANT_MAIN: o, HUI_ROOT: _, HA_DRAWER: r, HEADER: a, HA_SIDEBAR: l} = this.HAElements;
                this.ha = yield i.element,
                this.main = yield o.selector.$.element,
                this.huiRoot = yield _.selector.$.element,
                this.drawerLayout = yield r.element,
                this.appToolbar = yield a.selector.query(He.TOOLBAR).element,
                this.sideBarRoot = yield l.selector.$.element,
                this.user = yield n( () => {
                    var e, t;
                    return null === (t = null === (e = this.ha) || void 0 === e ? void 0 : e.hass) || void 0 === t ? void 0 : t.user
                }
                , e => !!e, {
                    retries: 500,
                    delay: 50,
                    rejectMessage: `${Ee}: Cannot select ${He.HOME_ASSISTANT} > hass > user after {{ retries }} attempts. Giving up!`
                }),
                this._renderer = yield new Oe(this.ha).getRenderer(),
                this.version = (e => {
                    const t = e ? e.match(/^(\d+)\.(\d+)\.(\w+)(?:\.(\w+))?$/) : null;
                    return t ? [+t[1], +t[2], t[3]] : null
                }
                )(null === (s = null === (e = this.ha.hass) || void 0 === e ? void 0 : e.config) || void 0 === s ? void 0 : s.version),
                this.run()
            })),
            t.addEventListener(M.ON_MORE_INFO_DIALOG_OPEN, e => {
                this.HAMoreInfoDialogElements = e.detail,
                this.insertMoreInfoDialogStyles()
            }
            ),
            t.addEventListener(M.ON_HISTORY_AND_LOGBOOK_DIALOG_OPEN, e => {
                this.HAMoreInfoDialogElements = e.detail,
                this.insertMoreInfoDialogStyles()
            }
            ),
            t.listen(),
            this.resizeWindowBinded = this.resizeWindow.bind(this)
        }
        _getPanelUrl() {
            return this.ha.hass.panelUrl
        }
        _hasStoredOptions() {
            const e = this._getPanelUrl();
            return this.panelOptions.has(e)
        }
        _getOptions() {
            var e;
            const t = this._getPanelUrl();
            return null !== (e = this.panelOptions.get(t)) && void 0 !== e ? e : {}
        }
        _storeOptions(e) {
            const t = this._getPanelUrl();
            this.panelOptions.set(t, e)
        }
        _isDebug(e) {
            return "boolean" == typeof e && e
        }
        _isKioskModeDisabled(e) {
            return !(e && (!Me(de.DISABLE_KIOSK_MODE) || e[Ae.IGNORE_DISABLE_KM]))
        }
        runThrottle() {
            window.clearTimeout(this._runTimeout),
            this._runTimeout = window.setTimeout( () => {
                this.run(),
                this.runDialogs()
            }
            , 50)
        }
        run() {
            return e(this, void 0, void 0, function*() {
                const e = this.main.querySelector(He.HA_PANEL_LOVELACE);
                if (e)
                    return this._hasStoredOptions() ? void this.insertStyles() : n( () => {
                        var t;
                        return null === (t = null == e ? void 0 : e.lovelace) || void 0 === t ? void 0 : t.config
                    }
                    , e => !!e, {
                        retries: 500,
                        delay: 50,
                        rejectMessage: `${Ee}: Cannot select Lovelace config after {{ retries }} attempts. Giving up!`
                    }).then(e => this.processConfig(e.kiosk_mode || {}))
            })
        }
        runDialogs() {
            var e, t, s;
            const n = null === (t = null === (e = this.ha) || void 0 === e ? void 0 : e.shadowRoot) || void 0 === t ? void 0 : t.querySelector(He.HA_MORE_INFO_DIALOG)
              , i = null === (s = null == n ? void 0 : n.shadowRoot) || void 0 === s ? void 0 : s.querySelector(He.HA_DIALOG);
            i && i.open && this.insertMoreInfoDialogStyles()
        }
        processConfig(t) {
            return e(this, void 0, void 0, function*() {
                this._isDebug(t.debug) && qe.debugRawConfig(t, this._getPanelUrl());
                let s = {};
                const i = {};
                var o;
                Object.values(Ie).forEach(e => {
                    s[e] = !1,
                    i[e] = !1
                }
                ),
                Object.values(Ae).forEach(e => {
                    s[e] = !1,
                    i[e] = !1
                }
                ),
                Object.values(ce).forEach(e => {
                    s[e] = !1,
                    i[e] = !1
                }
                ),
                (o = this.ha,
                e(void 0, void 0, void 0, function*() {
                    const e = Object.entries(Ne)
                      , t = yield n( () => e.map(e => {
                        const [t,s] = e;
                        return [o.hass.localize(s), t]
                    }
                    ), e => !e.find(e => !e[0]), {
                        retries: 500,
                        delay: 50
                    });
                    return Object.fromEntries(t)
                })).then(e => {
                    this.menuTranslations = e,
                    this.updateMenuItemsLabels()
                }
                ).catch( () => {
                    console.warn(`${Ee}: [ Non critial warning ] Cannot get resources translations`)
                }
                ),
                we(...Object.values(Ie)) || Me(...Object.values(Ie)) ? Object.values(Ie).forEach(e => {
                    s[e] = we(e) || Me(e)
                }
                ) : s = Object.assign(Object.assign({}, s), t);
                const _ = this.user.is_admin ? t.admin_settings : t.non_admin_settings;
                _ && (s = Object.assign(Object.assign({}, s), _)),
                t.user_settings && t.user_settings.forEach(e => {
                    e.users.some(e => e.toLowerCase() === this.user.name.toLowerCase()) && (s = Object.assign(Object.assign({}, s), e))
                }
                );
                const r = s[Ae.IGNORE_MOBILE_SETTINGS] ? null : t.mobile_settings;
                if (r) {
                    const e = r.custom_width ? r.custom_width : 812;
                    window.innerWidth <= e && (s = Object.assign(Object.assign({}, s), r))
                }
                if (this._isDebug(s.debug)) {
                    const {admin_settings: e, non_admin_settings: t, user_settings: n, mobile_settings: i} = s
                      , o = function(e, t) {
                        var s = {};
                        for (var n in e)
                            Object.prototype.hasOwnProperty.call(e, n) && t.indexOf(n) < 0 && (s[n] = e[n]);
                        if (null != e && "function" == typeof Object.getOwnPropertySymbols) {
                            var i = 0;
                            for (n = Object.getOwnPropertySymbols(e); i < n.length; i++)
                                t.indexOf(n[i]) < 0 && Object.prototype.propertyIsEnumerable.call(e, n[i]) && (s[n[i]] = e[n[i]])
                        }
                        return s
                    }(s, ["admin_settings", "non_admin_settings", "user_settings", "mobile_settings"]);
                    qe.debugFinalConfig(o, this._getPanelUrl())
                }
                this.setOptions(i, s),
                this._storeOptions(i),
                this.insertStyles()
            })
        }
        insertStyles() {
            var e, t, s;
            const n = this._getOptions();
            if (!this._isKioskModeDisabled(n)) {
                if (n[Ie.KIOSK] || n[Ie.HIDE_HEADER] ? (this.styleManager.addStyle(Be.HEADER, this.huiRoot),
                Me(de.CACHE) && be(me, Ie.HIDE_HEADER)) : this.styleManager.removeStyle(this.huiRoot),
                null === (t = null === (e = this.main) || void 0 === e ? void 0 : e.host) || void 0 === t || t.removeEventListener(Ce, this.blockEventHandler, !0),
                n[Ie.KIOSK] || n[Ie.HIDE_SIDEBAR]) {
                    const e = () => {
                        var t, s;
                        null === (s = null === (t = this.main) || void 0 === t ? void 0 : t.host) || void 0 === s || s.addEventListener(Ce, this.blockEventHandler, !0),
                        this.styleManager.addStyle(Be.SIDEBAR, this.drawerLayout),
                        this.styleManager.addStyle(Be.ASIDE, this.drawerLayout.shadowRoot),
                        Me(de.CACHE) && be(me, Ie.HIDE_SIDEBAR),
                        this.drawerLayout.removeEventListener(ge, e)
                    }
                    ;
                    "modal" === this.drawerLayout.type && (null === (s = this.drawerLayout.appContent) || void 0 === s ? void 0 : s.inert) ? this.drawerLayout.addEventListener(ge, e) : e()
                } else
                    this.styleManager.removeStyle(this.drawerLayout),
                    this.styleManager.removeStyle(this.drawerLayout.shadowRoot);
                if (n[Ie.HIDE_SETTINGS] || n[Ie.HIDE_NOTIFICATIONS] || n[Ie.HIDE_ACCOUNT] || n[Ie.HIDE_MENU_BUTTON]) {
                    const e = Ue([[n[Ie.HIDE_SETTINGS], Be.SETTINGS], [n[Ie.HIDE_NOTIFICATIONS], Be.NOTIFICATIONS], [n[Ie.HIDE_ACCOUNT], Be.ACCOUNT], [n[Ie.HIDE_SETTINGS] && n[Ie.HIDE_ACCOUNT] && n[Ie.HIDE_NOTIFICATIONS], Be.LIST_AFTER_SPACER], [n[Ie.HIDE_MENU_BUTTON], Be.MENU_BUTTON]]);
                    this.styleManager.addStyle(e, this.sideBarRoot),
                    Me(de.CACHE) && (n[Ie.HIDE_SETTINGS] && be(me, Ie.HIDE_SETTINGS),
                    n[Ie.HIDE_ACCOUNT] && be(me, Ie.HIDE_ACCOUNT),
                    n[Ie.HIDE_NOTIFICATIONS] && be(me, Ie.HIDE_NOTIFICATIONS))
                } else
                    this.styleManager.removeStyle(this.sideBarRoot);
                if (n[Ie.HIDE_ADD_TO_HOME_ASSISTANT] || n[Ie.HIDE_OVERFLOW] || n[Ie.HIDE_SEARCH] || n[Ie.HIDE_ASSISTANT] || n[Ie.HIDE_REFRESH] || n[Ie.HIDE_UNUSED_ENTITIES] || n[Ie.HIDE_RELOAD_RESOURCES] || n[Ie.HIDE_EDIT_DASHBOARD] || n[Ie.BLOCK_OVERFLOW] || n[Ie.HIDE_SIDEBAR] || n[Ie.HIDE_MENU_BUTTON]) {
                    const e = Ue([[n[Ie.HIDE_ADD_TO_HOME_ASSISTANT], Be.ADD_TO_HOME_ASSISTANT], [n[Ie.HIDE_OVERFLOW], Be.OVERFLOW_MENU], [n[Ie.HIDE_SEARCH], Be.SEARCH], [n[Ie.HIDE_ASSISTANT], Be.ASSISTANT], [n[Ie.HIDE_REFRESH], Be.REFRESH], [n[Ie.HIDE_UNUSED_ENTITIES], Be.UNUSED_ENTITIES], [n[Ie.HIDE_RELOAD_RESOURCES], Be.RELOAD_RESOURCES], [n[Ie.HIDE_EDIT_DASHBOARD], Be.EDIT_DASHBOARD], [n[Ie.BLOCK_OVERFLOW], Be.BLOCK_OVERFLOW], [n[Ie.HIDE_MENU_BUTTON] || n[Ie.HIDE_SIDEBAR], Be.MENU_BUTTON_BURGER]]);
                    this.styleManager.addStyle(e, this.appToolbar),
                    Me(de.CACHE) && (n[Ie.HIDE_ADD_TO_HOME_ASSISTANT] && be(me, Ie.HIDE_ADD_TO_HOME_ASSISTANT),
                    n[Ie.HIDE_OVERFLOW] && be(me, Ie.HIDE_OVERFLOW),
                    n[Ie.HIDE_SEARCH] && be(me, Ie.HIDE_SEARCH),
                    n[Ie.HIDE_ASSISTANT] && be(me, Ie.HIDE_ASSISTANT),
                    n[Ie.HIDE_REFRESH] && be(me, Ie.HIDE_REFRESH),
                    n[Ie.HIDE_UNUSED_ENTITIES] && be(me, Ie.HIDE_UNUSED_ENTITIES),
                    n[Ie.HIDE_RELOAD_RESOURCES] && be(me, Ie.HIDE_RELOAD_RESOURCES),
                    n[Ie.HIDE_EDIT_DASHBOARD] && be(me, Ie.HIDE_EDIT_DASHBOARD),
                    n[Ie.BLOCK_OVERFLOW] && be(me, Ie.BLOCK_OVERFLOW),
                    n[Ie.HIDE_MENU_BUTTON] && be(me, Ie.HIDE_MENU_BUTTON))
                } else
                    this.styleManager.removeStyle(this.appToolbar);
                n[Ie.BLOCK_MOUSE] ? (this.styleManager.addStyle(Be.MOUSE, document.body),
                Me(de.CACHE) && be(me, Ie.BLOCK_MOUSE)) : this.styleManager.removeStyle(document.body),
                window.removeEventListener("contextmenu", this.blockEventHandler, !0),
                n[Ie.BLOCK_CONTEXT_MENU] && (window.addEventListener("contextmenu", this.blockEventHandler, !0),
                Me(de.CACHE) && be(me, Ie.BLOCK_CONTEXT_MENU)),
                window.removeEventListener(ve, this.resizeWindowBinded),
                window.addEventListener(ve, this.resizeWindowBinded),
                window.dispatchEvent(new Event(ve))
            }
        }
        insertMoreInfoDialogStyles() {
            return e(this, void 0, void 0, function*() {
                const e = this._getOptions();
                if (this._isKioskModeDisabled(e))
                    return;
                this.HAMoreInfoDialogElements.HA_DIALOG.selector.query(`:scope > ${He.MENU_ITEM}`).all.then(e => {
                    ( (e, t) => {
                        e.forEach(e => {
                            if (e) {
                                const s = e.shadowRoot.querySelector(He.HA_BUTTON);
                                e.dataset.selector = t[s.title.trim()]
                            }
                        }
                        )
                    }
                    )(e, this.menuTranslations)
                }
                );
                const t = yield this.HAMoreInfoDialogElements.HA_DIALOG.element
                  , s = this.HAMoreInfoDialogElements.HA_DIALOG_CONTENT.selector.query(`${He.HA_DIALOG_MORE_INFO}, ${He.HA_DIALOG_MORE_INFO_HISTORY_AND_LOGBOOK}`).$
                  , n = yield s.element;
                if (e[Ie.HIDE_DIALOG_HEADER_BREADCRUMB_NAVIGATION] || e[Ie.HIDE_DIALOG_HEADER_ACTION_ITEMS] || e[Ie.HIDE_DIALOG_HEADER_HISTORY] || e[Ie.HIDE_DIALOG_HEADER_SETTINGS] || e[Ie.HIDE_DIALOG_HEADER_OVERFLOW]) {
                    const s = Ue([[e[Ie.HIDE_DIALOG_HEADER_BREADCRUMB_NAVIGATION], Be.DIALOG_HEADER_BREADCRUMB_NAVIGATION], [e[Ie.HIDE_DIALOG_HEADER_ACTION_ITEMS] || e[Ie.HIDE_DIALOG_HEADER_HISTORY], Be.DIALOG_HEADER_HISTORY], [e[Ie.HIDE_DIALOG_HEADER_ACTION_ITEMS] || e[Ie.HIDE_DIALOG_HEADER_SETTINGS], Be.DIALOG_HEADER_SETTINGS], [e[Ie.HIDE_DIALOG_HEADER_ACTION_ITEMS] || e[Ie.HIDE_DIALOG_HEADER_OVERFLOW], Be.DIALOG_HEADER_OVERFLOW]]);
                    this.styleManager.addStyle(s, t),
                    Me(de.CACHE) && (e[Ie.HIDE_DIALOG_HEADER_BREADCRUMB_NAVIGATION] && be(me, Ie.HIDE_DIALOG_HEADER_BREADCRUMB_NAVIGATION),
                    e[Ie.HIDE_DIALOG_HEADER_ACTION_ITEMS] && be(me, Ie.HIDE_DIALOG_HEADER_ACTION_ITEMS),
                    e[Ie.HIDE_DIALOG_HEADER_HISTORY] && be(me, Ie.HIDE_DIALOG_HEADER_HISTORY),
                    e[Ie.HIDE_DIALOG_HEADER_SETTINGS] && be(me, Ie.HIDE_DIALOG_HEADER_SETTINGS),
                    e[Ie.HIDE_DIALOG_HEADER_OVERFLOW] && be(me, Ie.HIDE_DIALOG_HEADER_OVERFLOW))
                } else
                    this.styleManager.removeStyle(t);
                const i = s.query(He.HA_DIALOG_MORE_INFO_CONTENT).$.query(He.HA_DIALOG_CLIMATE).$
                  , o = i.query(He.HA_STATE_CONTROL_CLIMATE_TEMPERATURE).$
                  , _ = o.query(He.HA_DIALOG_CLIMATE_CIRCULAR_SLIDER).$;
                i.element.then(t => {
                    e[Ie.HIDE_DIALOG_CLIMATE_ACTIONS] || e[Ie.HIDE_DIALOG_CLIMATE_SETTINGS_ACTIONS] ? (this.styleManager.addStyle(Be.DIALOG_CLIMATE_CONTROL_SELECT, t),
                    Me(de.CACHE) && (e[Ie.HIDE_DIALOG_CLIMATE_ACTIONS] && be(me, Ie.HIDE_DIALOG_CLIMATE_ACTIONS),
                    e[Ie.HIDE_DIALOG_CLIMATE_SETTINGS_ACTIONS] && be(me, Ie.HIDE_DIALOG_CLIMATE_SETTINGS_ACTIONS))) : this.styleManager.removeStyle(t)
                }
                ),
                o.element.then(t => {
                    e[Ie.HIDE_DIALOG_CLIMATE_ACTIONS] || e[Ie.HIDE_DIALOG_CLIMATE_TEMPERATURE_ACTIONS] ? (this.styleManager.addStyle(Be.DIALOG_CLIMATE_TEMPERATURE_BUTTONS, t),
                    Me(de.CACHE) && e[Ie.HIDE_DIALOG_CLIMATE_TEMPERATURE_ACTIONS] && be(me, Ie.HIDE_DIALOG_CLIMATE_TEMPERATURE_ACTIONS)) : this.styleManager.removeStyle(t)
                }
                ),
                _.element.then(t => {
                    e[Ie.HIDE_DIALOG_CLIMATE_ACTIONS] || e[Ie.HIDE_DIALOG_CLIMATE_TEMPERATURE_ACTIONS] ? this.styleManager.addStyle(Be.DIALOG_CLIMATE_CIRCULAR_SLIDER_INTERACTION, t) : this.styleManager.removeStyle(t)
                }
                );
                if (s.query(He.HA_DIALOG_MORE_INFO_CONTENT).$.query([He.HA_DIALOG_DEFAULT, He.HA_DIALOG_LIGHT, He.HA_DIALOG_LOCK, He.HA_DIALOG_MEDIA_PLAYER, He.HA_DIALOG_PERSON, He.HA_DIALOG_SIREN, He.HA_DIALOG_TIMER, He.HA_DIALOG_UPDATE, He.HA_DIALOG_VACUUM, He.HA_DIALOG_CAMERA].join(",")).$.element.then(t => {
                    if (e[Ie.HIDE_DIALOG_TIMER_ACTIONS] || e[Ie.HIDE_DIALOG_MEDIA_ACTIONS] || e[Ie.HIDE_DIALOG_UPDATE_ACTIONS] || e[Ie.HIDE_DIALOG_CAMERA_ACTIONS] || e[Ie.HIDE_DIALOG_LIGHT_ACTIONS] || e[Ie.HIDE_DIALOG_LIGHT_CONTROL_ACTIONS] || e[Ie.HIDE_DIALOG_LIGHT_COLOR_ACTIONS] || e[Ie.HIDE_DIALOG_LIGHT_SETTINGS_ACTIONS]) {
                        const s = Ue([[e[Ie.HIDE_DIALOG_TIMER_ACTIONS] && t.host.localName === He.HA_DIALOG_TIMER, Be.DIALOG_TIMER_ACTIONS], [e[Ie.HIDE_DIALOG_MEDIA_ACTIONS] && t.host.localName === He.HA_DIALOG_MEDIA_PLAYER, Be.DIALOG_MEDIA_ACTIONS], [e[Ie.HIDE_DIALOG_UPDATE_ACTIONS] && t.host.localName === He.HA_DIALOG_UPDATE, Be.DIALOG_UPDATE_ACTIONS], [t.host.localName === He.HA_DIALOG_CAMERA, Be.DIALOG_CAMERA_ACTIONS], [e[Ie.HIDE_DIALOG_LIGHT_ACTIONS] || e[Ie.HIDE_DIALOG_LIGHT_CONTROL_ACTIONS], Be.DIALOG_LIGHT_CONTROL_ACTIONS], [e[Ie.HIDE_DIALOG_LIGHT_ACTIONS] || e[Ie.HIDE_DIALOG_LIGHT_COLOR_ACTIONS], Be.DIALOG_LIGHT_COLOR_ACTIONS], [e[Ie.HIDE_DIALOG_LIGHT_ACTIONS] || e[Ie.HIDE_DIALOG_LIGHT_SETTINGS_ACTIONS], Be.DIALOG_LIGHT_SETTINGS_ACTIONS]]);
                        this.styleManager.addStyle(s, t),
                        Me(de.CACHE) && (e[Ie.HIDE_DIALOG_TIMER_ACTIONS] && be(me, Ie.HIDE_DIALOG_TIMER_ACTIONS),
                        e[Ie.HIDE_DIALOG_MEDIA_ACTIONS] && be(me, Ie.HIDE_DIALOG_MEDIA_ACTIONS),
                        e[Ie.HIDE_DIALOG_UPDATE_ACTIONS] && be(me, Ie.HIDE_DIALOG_UPDATE_ACTIONS),
                        e[Ie.HIDE_DIALOG_CAMERA_ACTIONS] && be(me, Ie.HIDE_DIALOG_CAMERA_ACTIONS),
                        e[Ie.HIDE_DIALOG_LIGHT_ACTIONS] && be(me, Ie.HIDE_DIALOG_LIGHT_ACTIONS),
                        e[Ie.HIDE_DIALOG_LIGHT_CONTROL_ACTIONS] && be(me, Ie.HIDE_DIALOG_LIGHT_CONTROL_ACTIONS),
                        e[Ie.HIDE_DIALOG_LIGHT_COLOR_ACTIONS] && be(me, Ie.HIDE_DIALOG_LIGHT_COLOR_ACTIONS),
                        e[Ie.HIDE_DIALOG_LIGHT_SETTINGS_ACTIONS] && be(me, Ie.HIDE_DIALOG_LIGHT_SETTINGS_ACTIONS))
                    } else
                        this.styleManager.removeStyle(t)
                }
                ),
                e[Ie.HIDE_DIALOG_HISTORY] || e[Ie.HIDE_DIALOG_LOGBOOK]) {
                    const t = Ue([[e[Ie.HIDE_DIALOG_HISTORY], Be.DIALOG_HISTORY], [e[Ie.HIDE_DIALOG_LOGBOOK], Be.DIALOG_LOGBOOK]]);
                    this.styleManager.addStyle(t, n),
                    Me(de.CACHE) && (e[Ie.HIDE_DIALOG_HISTORY] && be(me, Ie.HIDE_DIALOG_HISTORY),
                    e[Ie.HIDE_DIALOG_LOGBOOK] && be(me, Ie.HIDE_DIALOG_LOGBOOK))
                } else
                    this.styleManager.removeStyle(n);
                s.query(He.HA_DIALOG_HISTORY).$.element.then(t => {
                    e[Ie.HIDE_DIALOG_HISTORY_SHOW_MORE] ? (this.styleManager.addStyle(Be.DIALOG_SHOW_MORE, t),
                    Me(de.CACHE) && be(me, Ie.HIDE_DIALOG_HISTORY_SHOW_MORE)) : this.styleManager.removeStyle(t)
                }
                );
                s.query(He.HA_DIALOG_LOGBOOK).$.element.then(t => {
                    e[Ie.HIDE_DIALOG_LOGBOOK_SHOW_MORE] ? (this.styleManager.addStyle(Be.DIALOG_SHOW_MORE, t),
                    Me(de.CACHE) && be(me, Ie.HIDE_DIALOG_LOGBOOK_SHOW_MORE)) : this.styleManager.removeStyle(t)
                }
                )
            })
        }
        resizeWindow() {
            window.clearTimeout(this.resizeDelay),
            this.resizeDelay = window.setTimeout( () => {
                this.updateMenuItemsLabels()
            }
            , 250)
        }
        updateMenuItemsLabels() {
            if (!this.menuTranslations)
                return;
            this.HAElements.HEADER.selector.query(`${He.TOOLBAR} > ${He.ACTION_ITEMS} > ${He.MENU_ITEM}`).all.then(e => {
                ( (e, t) => {
                    e.forEach(e => {
                        if (e && e.dataset && !e.dataset.selector) {
                            const s = e.getAttribute("aria-labelledby");
                            if (!s)
                                return;
                            const n = e.parentElement.querySelector(`#${s.trim()}`);
                            if (!n)
                                return;
                            const i = Pe(n.textContent);
                            e.dataset.selector = t[i]
                        }
                    }
                    )
                }
                )(e, this.menuTranslations)
            }
            );
            const e = this.HAElements.HEADER.selector.query(`${He.TOOLBAR} > ${He.ACTION_ITEMS} > ${He.DROPDOWN}`).all
              , t = this.HAElements.HEADER.selector.query(`${He.TOOLBAR} > ${He.ACTION_ITEMS} > ${He.DROPDOWN}[placement="bottom-start"] ${He.DROPDOWN_MENU_ITEM}`).all;
            Promise.all([e, t]).then( ([e,t]) => {
                ( (e, t) => {
                    e.forEach(e => {
                        const s = e.querySelector(He.MENU_ITEM);
                        if (s) {
                            const e = s.shadowRoot.querySelector(He.HA_BUTTON);
                            s.dataset.selector = t[e.getAttribute("aria-label").trim()]
                        }
                    }
                    )
                }
                )(e, this.menuTranslations),
                ( (e, t) => {
                    e.forEach(e => {
                        if (e) {
                            const s = Pe(e.textContent);
                            e.dataset.selector = t[s]
                        }
                    }
                    )
                }
                )(t, this.menuTranslations)
            }
            )
        }
        blockEventHandler(e) {
            e.preventDefault(),
            e.stopImmediatePropagation()
        }
        setOptions(e, t) {
            Object.values(Object.assign(Object.assign({}, ce), Ie)).forEach(s => {
                s in t && this.setOptionsOrSubscribeToSetOptions(e, t, s)
            }
            ),
            Ae.IGNORE_DISABLE_KM in t && this.setOptionsOrSubscribeToSetOptions(e, t, Ae.IGNORE_DISABLE_KM)
        }
        setOptionsOrSubscribeToSetOptions(e, t, s) {
            const n = this._getPanelUrl()
              , i = t[s]
              , o = (t, i) => {
                this._getPanelUrl() === n && (s === ce.DEBUG_TEMPLATE ? qe.debugTemplate(t, i) : (this._isDebug(e.debug) && qe.debug(s, t, i),
                this.runThrottle()))
            }
            ;
            if ("boolean" == typeof i)
                e[s] = i;
            else if (fe.test(i)) {
                const t = t => {
                    e[s] = "boolean" == typeof t && t,
                    o(i, t)
                }
                ;
                this._renderer.trackTemplate(i.replace(fe, "$1"), t)
            } else {
                if (!Ge.test(i))
                    throw SyntaxError(`${Ee}: the value "${i}" of the option "${s}" is not a well formed JavaScript or Jinja template`);
                window.hassConnection.then(t => {
                    t.conn.subscribeMessage(t => {
                        const n = t.result;
                        e[s] = "boolean" == typeof n && n,
                        o(i, n)
                    }
                    , {
                        type: "render_template",
                        template: i,
                        variables: {
                            user_name: this.ha.hass.user.name,
                            user_is_admin: this.ha.hass.user.is_admin,
                            user_is_owner: this.ha.hass.user.is_owner,
                            user_agent: window.navigator.userAgent
                        }
                    })
                }
                )
            }
        }
    }
    Promise.resolve(customElements.whenDefined(He.HUI_VIEW)).then( () => {
        window.KioskMode = new ze
    }
    )
}();