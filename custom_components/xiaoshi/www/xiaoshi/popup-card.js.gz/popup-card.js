window.GlobalPopupController = {
  hass: null,
  _popupStack: [],
  _escHandler: null,
  _hassUnsubscribe: null,
  _updatePending: false,
  _hassVersion: 0,
  _retryTimers: [],       // 追踪所有重试定时器
  _pollTimer: null,       // 服务拦截轮询定时器
  _cardCache: new Map(),  // 卡片元素缓存 (LRU, 最大5条)
  _isVisible: true,       // 页面是否可见
  _staleUpdate: false,    // 页面不可见期间是否有待处理的更新

  init() {
    this._startHassWatcher();
  },

  // 判断字符串是否像 Home Assistant 实体ID
  _isEntityId(str) {
    return typeof str === 'string' && /^[a-z_][a-z0-9_]*\.[a-z_][a-z0-9_]*$/.test(str);
  },

  // 从卡片配置中递归提取所有关联的实体ID（深度扫描所有字段）
  _extractEntities(config) {
    const entities = new Set();
    if (!config) return entities;

    if (typeof config === 'string') {
      if (this._isEntityId(config)) entities.add(config);
      return entities;
    }

    if (Array.isArray(config)) {
      config.forEach(item => this._extractEntities(item).forEach(e => entities.add(e)));
      return entities;
    }

    if (typeof config === 'object') {
      for (const [key, value] of Object.entries(config)) {
        // 跳过 type、theme 等非实体字段
        if (key === 'type' || key === 'theme') continue;
        this._extractEntities(value).forEach(e => entities.add(e));
      }
    }

    return entities;
  },

  // 生成卡片配置的缓存 key
  _cacheKey(cardConfig) {
    return JSON.stringify(cardConfig);
  },

  // 从缓存获取卡片元素 (LRU)
  _getCachedCard(cardConfig) {
    const key = this._cacheKey(cardConfig);
    const cached = this._cardCache.get(key);
    if (cached && cached.cardElement) {
      this._cardCache.delete(key);
      this._cardCache.set(key, cached);
      return cached.cardElement;
    }
    return null;
  },

  // 将卡片元素存入缓存 (超出上限时淘汰最旧的)
  _cacheCard(cardConfig, cardElement) {
    const key = this._cacheKey(cardConfig);
    this._cardCache.delete(key);

    if (this._cardCache.size >= 5) {
      const oldestKey = this._cardCache.keys().next().value;
      this._cardCache.delete(oldestKey);
    }

    this._cardCache.set(key, { cardElement });
  },

  // 清空卡片缓存
  _clearCardCache() {
    this._cardCache.clear();
  },

  // 启动服务拦截轮询
  _startPollTimer() {
    if (this._pollTimer) return;
    this._pollTimer = setInterval(() => {
      const haRoot = document.querySelector('home-assistant');
      const hassObj = haRoot?.hass || haRoot?.shadowRoot?.querySelector('home-assistant-main')?.hass;
      if (hassObj && hassObj.callService && !hassObj._originalCallService) {
        interceptCallService();
      }
    }, 3000);
  },

  // 停止服务拦截轮询
  _stopPollTimer() {
    if (this._pollTimer) {
      clearInterval(this._pollTimer);
      this._pollTimer = null;
    }
  },

  // 订阅 hass 状态变化
  _startHassWatcher() {
    const haRoot = document.querySelector('home-assistant');
    const hass = haRoot?.hass || haRoot?.shadowRoot?.querySelector('home-assistant-main')?.hass;

    if (!hass || !hass.connection) {
      const timer = setTimeout(() => this._startHassWatcher(), 500);
      this._retryTimers.push(timer);
      return;
    }

    this.hass = hass;

    try {
      hass.connection.subscribeMessage(
        (msg) => {
          if (this._popupStack.length === 0) return;

          const entityId = msg.data?.entity_id;
          if (!entityId) return;

          // 检查是否有弹窗关心这个实体的变化
          const needsUpdate = this._popupStack.some(popupInfo => {
            const tracked = popupInfo._trackedEntities;
            // 未追踪或追踪了该实体时需要更新
            return !tracked || tracked.size === 0 || tracked.has(entityId);
          });

          if (!needsUpdate) return;

          // 使用 RAF 批处理，合并同一帧内的多次状态变化
          this._scheduleUpdate();
        },
        { type: 'subscribe_events', event_type: 'state_changed' }
      ).then((unsub) => {
        this._hassUnsubscribe = unsub;
      });
    } catch (err) {
      console.error('[popup_card] 订阅状态变化失败:', err);
    }
  },

  // RAF 批处理调度，每帧最多触发一次更新
  _scheduleUpdate() {
    if (this._updatePending) return;
    // 页面不可见时标记为待更新，回来后统一处理
    if (!this._isVisible) {
      this._staleUpdate = true;
      return;
    }
    this._updatePending = true;
    requestAnimationFrame(() => {
      this._updatePending = false;
      const haRoot = document.querySelector('home-assistant');
      const newHass = haRoot?.hass || haRoot?.shadowRoot?.querySelector('home-assistant-main')?.hass;

      // hass 引用未变化时跳过（HA 通常在状态变化时更新 hass 对象引用）
      if (newHass === this.hass) return;
      this.hass = newHass;
      this._updateAllCards();
    });
  },

  // 只更新需要刷新的弹窗卡片
  _updateAllCards() {
    this._popupStack.forEach(popupInfo => {
      if (popupInfo.cardElement && this.hass) {
        try {
          popupInfo.cardElement.hass = this.hass;
        } catch (err) {
          // 卡片可能已销毁，从栈中标记移除
          console.warn('[popup_card] 更新卡片失败，可能已销毁:', err.message);
        }
      }
    });
  },

  async show(options) {
    const { card, title } = options;
    const hide_header = options.hide_header !== undefined ? options.hide_header : true;
    const background = options.background || '';
    const gap = options.popup_gap;
    const width = options.popup_width || '95%';
    const top = options.popup_top || '20px';
    const transform = top === '50%' ? 'translate(-50%, -50%)' : 'translateX(-50%)';

    // === iOS 安全区（刘海 / 状态栏 / Home 指示条）避让 ===
    // 参数 popup_safe_area：'auto'（默认，自动避让）/ 'on'（强制）/ 'off'（关闭，保持旧版全屏贴合）
    const safeAreaMode = options.popup_safe_area || 'auto';
    // 取 max(HA变量, env())：HA 的 --safe-area-inset-* 在 App 里可能被覆盖成 0px，
    // 而 env() 才是 iOS 硬件真实的刘海/状态栏高度，两者取大值才不会漏掉状态栏。
    // 主题里若显式定义 --kiosk-safe-top / --kiosk-safe-bottom，则以主题值为准（手动兜底入口），
    // 与 xiaoshi-phone-card 的约定保持一致。
    const safeTopExpr = 'var(--kiosk-safe-top, max(var(--safe-area-inset-top, 0px), env(safe-area-inset-top, 0px)))';
    const safeBottomExpr = 'var(--kiosk-safe-bottom, max(var(--safe-area-inset-bottom, 0px), env(safe-area-inset-bottom, 0px)))';
    const safeOn = { auto: true, on: true, off: false }[safeAreaMode] !== false;
    // 间距统一走 --popup-safe-gap，便于一处调参；--popup-safe-extra-top 给悬浮头部额外留白
    const safeVars = safeOn
      ? `--popup-safe-gap: ${safeTopExpr}; --popup-safe-extra-top: ${safeTopExpr}; --popup-safe-bottom: ${safeBottomExpr};`
      : `--popup-safe-gap: 0px; --popup-safe-extra-top: 0px; --popup-safe-bottom: 0px;`;

    // 检测是否为移动端
    const isMobile = window.innerWidth < 768;

    // 处理数组格式的 card
    let cardConfig = card;
    if (Array.isArray(card)) {
      cardConfig = { type: 'vertical-stack', cards: card };
    }

    // 计算正确的 z-index
    const baseZ = 1000 + this._popupStack.length * 10;
    const overlayZIndex = baseZ;
    const zIndex = baseZ + 5;

    // 创建遮罩层
    const overlay = document.createElement('div');
    overlay.className = 'popup-card-overlay';
    overlay.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(0, 0, 0, 0.5);
      z-index: ${overlayZIndex};
      -webkit-backdrop-filter: blur(10px);
      backdrop-filter: blur(10px);
      ${safeVars}
      box-sizing: border-box;
      /* 安全区留白放在遮罩层：fixed + 子元素 absolute 不受内边距影响，
         弹窗按 padding box 起算 → 上下都避开刘海/Home 指示条，且点击留白处仍能关闭 */
      padding-top: var(--popup-safe-gap);
      padding-bottom: var(--popup-safe-bottom);
    `;

    // 点击遮罩关闭弹窗
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) {
        this.closeTop();
      }
    });

    // 获取添加目标
    const haRoot = document.querySelector('home-assistant');
    let appendTarget = document.body;

    if (haRoot?.shadowRoot) {
      const haMain = haRoot.shadowRoot.querySelector('home-assistant-main');
      if (haMain?.shadowRoot) {
        const lovelace = haMain.shadowRoot.querySelector('ha-panel-lovelace');
        if (lovelace?.shadowRoot) {
          const huiRoot = lovelace.shadowRoot.querySelector('hui-root');
          if (huiRoot) {
            appendTarget = huiRoot.shadowRoot || huiRoot;
          }
        }
      }
    }

    appendTarget.appendChild(overlay);

    // 创建弹窗容器
    const popup = document.createElement('div');
    popup.className = 'popup-card-popup';

    // 检测主题
    const isDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;

    // 根据是否有标题/头部调整样式
    if (hide_header === true) {
      // 隐藏头部模式
      popup.style.cssText = `
        position: fixed;
        top: ${top};
        left: 50%;
        transform: ${transform};
        z-index: ${zIndex};
        background: transparent;
        padding: 0;
        max-width: 100vw;
        /* 减去安全区留白，保证卡片整体不越过刘海 / Home 指示条 */
        max-height: calc(100vh - var(--popup-safe-gap) - var(--popup-safe-bottom));
        overflow: hidden;
        box-sizing: border-box;
        width: ${width};
        ${safeVars}
        ${background ? '--card-background-color: ' + background + ';' : ''}
        ${background ? '--ha-card-background: ' + background + ';' : ''}
        ${background ? '--ha-card-border-width:0;' : ''}
        ${gap !== undefined ? '--vertical-stack-card-gap: ' + gap + ';' : ''}
      `;
    } else {
      // 正常模式 - 响应式设计
      const padding = isMobile ? '12px' : '16px';
      const headerPadding = isMobile ? '44px' : '60px';

      popup.style.cssText = `
        position: fixed;
        top: ${top};
        left: 50%;
        transform: ${transform};
        z-index: ${zIndex};
        background: ${isDark ? 'rgba(20, 20, 20, 0.6)' : 'rgba(255, 255, 255, 0.6)'};
        border-radius: ${isMobile ? '12px' : '16px'};
        padding: ${headerPadding} ${padding} ${padding} ${padding};
        max-width: 100vw;
        /* 减去安全区留白，保证卡片整体不越过刘海 / Home 指示条 */
        max-height: calc(100vh - var(--popup-safe-gap) - var(--popup-safe-bottom));
        overflow: hidden;
        animation: popupFadeIn 0.2s ease-out;
        box-sizing: border-box;
        width: ${width};
        ${safeVars}
        ${background ? '--card-background-color: ' + background + ';' : ''}
        ${background ? '--ha-card-background: ' + background + ';' : ''}
        ${background ? '--ha-card-border-width:0;' : ''}
        ${gap !== undefined ? '--vertical-stack-card-gap: ' + gap + ';' : ''}
      `;

      // 添加标题
      if (title) {
        const titleEl = document.createElement('div');
        titleEl.className = 'popup-card-title';
        titleEl.textContent = title;
        titleEl.style.cssText = `
          position: absolute;
          top: calc(var(--popup-safe-extra-top, 0px) + ${isMobile ? '10px' : '12px'});
          left: 50%;
          transform: translateX(-50%);
          font-size: ${isMobile ? '14px' : '16px'};
          font-weight: 600;
          color: ${isDark ? 'rgba(255, 255, 255, 0.9)' : '#2c3e50'};
          white-space: nowrap;
          padding: 0 20px;
          box-sizing: border-box;
        `;
        popup.appendChild(titleEl);
      }

      // 添加关闭按钮
      const closeBtn = document.createElement('button');
      closeBtn.textContent = '✕';
      closeBtn.style.cssText = `
        position: absolute;
        top: calc(var(--popup-safe-extra-top, 0px) + ${isMobile ? '8px' : '10px'});
        right: ${isMobile ? '8px' : '12px'};
        width: ${isMobile ? '28px' : '32px'};
        height: ${isMobile ? '28px' : '32px'};
        border: none;
        background: ${isDark ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.05)'};
        color: ${isDark ? 'rgba(255, 255, 255, 0.9)' : '#2c3e50'};
        border-radius: 50%;
        cursor: pointer;
        font-size: ${isMobile ? '14px' : '16px'};
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 10;
      `;
      closeBtn.onclick = () => this.closeTop();
      popup.appendChild(closeBtn);
    }

    // 创建卡片内容容器（可滚动）
    const contentContainer = document.createElement('div');
    contentContainer.className = 'popup-card-content';
    const paddingValue = isMobile ? '12px' : '16px';
    contentContainer.style.cssText = `
      overflow-y: auto;
      overflow-x: visible;
      max-height: calc(100vh - var(--popup-safe-gap) - var(--popup-safe-bottom));
      -webkit-overflow-scrolling: touch;
      overscroll-behavior: contain;
      padding: 0;
      box-sizing: border-box;
      ${hide_header ? '' : 'padding-top: 8px;'}
    `;

    let cardElement = null;
    try {
      // 尝试从缓存获取卡片元素
      const cachedElement = this._getCachedCard(cardConfig);
      if (cachedElement) {
        cardElement = cachedElement;
        const haRoot = document.querySelector('home-assistant');
        this.hass = haRoot?.hass || haRoot?.shadowRoot?.querySelector('home-assistant-main')?.hass;
        if (this.hass) {
          cardElement.hass = this.hass;
        }
        contentContainer.appendChild(cardElement);
      } else {
        // 使用 Home Assistant 的卡片创建机制
        const helpers = await window.loadCardHelpers?.();
        if (helpers) {
          cardElement = await helpers.createCardElement(cardConfig);

          // 立即设置 hass
          const haRoot = document.querySelector('home-assistant');
          this.hass = haRoot?.hass || haRoot?.shadowRoot?.querySelector('home-assistant-main')?.hass;
          if (this.hass) {
            cardElement.hass = this.hass;
          }

          contentContainer.appendChild(cardElement);
        } else {
          // 备用方案：直接显示配置信息
          contentContainer.innerHTML = `
            <div style="padding: 20px;">
              <p><strong>卡片类型: ${cardConfig.type}</strong></p>
              <pre style="background: #f5f5f5; padding: 10px; border-radius: 8px; overflow: auto;">${JSON.stringify(cardConfig, null, 2)}</pre>
            </div>
          `;
        }
      }
    } catch (err) {
      console.error('[popup_card] 创建卡片失败:', err);
      contentContainer.innerHTML = `<div style="color: red; padding: 20px;">加载卡片失败: ${err.message}</div>`;
    }

    // 再包一层卡片内容容器：
    //  · hide_header 模式下它承担纵向滚动（外层 overflow:hidden，「视觉容器 == 内容容器」，隐藏 modal 不会延伸出可滚动范围）
    //  · 它是「视觉容器」本体，在这里加安全区内边距，卡片就整体避开刘海 / Home 指示条
    const cardBox = document.createElement('div');
    cardBox.className = 'popup-card-box';
    const isSquareTop = top === '50%';
    // 悬浮贴顶（auto）时把「safe-gap - top」补回顶部，让卡片顶边正好落在安全区下沿；
    // 居中（top === '50%'）与底部贴底（100%）不需要补偿
    const extraTop = (hide_header && safeOn && !isSquareTop) ? 'max(0px, calc(var(--popup-safe-extra-top) - ' + top + '))' : '0px';
    cardBox.style.cssText = `
      width: 100%;
      box-sizing: border-box;
      ${hide_header ? 'max-height: calc(100vh - var(--popup-safe-gap) - var(--popup-safe-bottom)); overflow-y: auto; -webkit-overflow-scrolling: touch; overscroll-behavior: contain;' : ''}
      padding-top: ${extraTop};
      padding-bottom: var(--popup-safe-bottom);
    `;
    cardBox.appendChild(contentContainer);
    popup.appendChild(cardBox);
    appendTarget.appendChild(popup);

    // 将弹窗添加到栈中（保存卡片引用 + 追踪实体 + 缓存配置）
    const trackedEntities = this._extractEntities(cardConfig);
    this._popupStack.push({ popup, overlay, appendTarget, cardElement, _trackedEntities: trackedEntities, _cardConfig: cardConfig });

    // 启动 hass 订阅（如果还没订阅）
    if (!this._hassUnsubscribe) {
      this._startHassWatcher();
    }

    // ESC 关闭最上层弹窗
    if (!this._escHandler) {
      this._escHandler = (e) => {
        if (e.key === 'Escape') this.closeTop();
      };
      window.addEventListener('keydown', this._escHandler);
    }
  },

  // 关闭最上层的弹窗
  closeTop() {
    if (this._popupStack.length === 0) return;

    const popupInfo = this._popupStack.pop();

    // 缓存卡片元素（从 popup DOM 中分离，保留元素供复用）
    if (popupInfo.cardElement && popupInfo._cardConfig) {
      popupInfo.cardElement.remove();
      this._cacheCard(popupInfo._cardConfig, popupInfo.cardElement);
    }

    popupInfo.overlay.remove();
    popupInfo.popup.remove();

    // 如果所有弹窗都关闭了，取消 hass 订阅
    if (this._popupStack.length === 0 && this._hassUnsubscribe) {
      this._hassUnsubscribe();
      this._hassUnsubscribe = null;
    }
  },

  // 关闭所有弹窗
  close() {
    // 从后往前关闭所有弹窗
    while (this._popupStack.length > 0) {
      const popupInfo = this._popupStack.pop();

      // 缓存卡片元素
      if (popupInfo.cardElement && popupInfo._cardConfig) {
        popupInfo.cardElement.remove();
        this._cacheCard(popupInfo._cardConfig, popupInfo.cardElement);
      }

      popupInfo.overlay.remove();
      popupInfo.popup.remove();
    }

    // 移除 ESC 监听器
    if (this._escHandler) {
      window.removeEventListener('keydown', this._escHandler);
      this._escHandler = null;
    }

    // 取消 hass 订阅
    if (this._hassUnsubscribe) {
      this._hassUnsubscribe();
      this._hassUnsubscribe = null;
    }

    // 停止服务拦截轮询
    this._stopPollTimer();

    // 清理所有重试定时器
    this._retryTimers.forEach(timer => clearTimeout(timer));
    this._retryTimers = [];

    // 取消待处理的 RAF 更新
    this._updatePending = false;
    this._staleUpdate = false;
  }
};

// 初始化全局控制器
window.GlobalPopupController.init();

// 拦截服务调用
let _interceptRetrying = false;
const interceptCallService = () => {
  const haRoot = document.querySelector('home-assistant');
  if (!haRoot) {
    if (!_interceptRetrying) {
      _interceptRetrying = true;
      const timer = setTimeout(() => {
        _interceptRetrying = false;
        interceptCallService();
      }, 500);
      window.GlobalPopupController._retryTimers.push(timer);
    }
    return;
  }

  // 查找 hass 对象
  let hassObj = haRoot.hass;
  if (!hassObj) {
    const main = haRoot.shadowRoot?.querySelector('home-assistant-main');
    if (main?.hass) {
      hassObj = main.hass;
    }
  }

  if (!hassObj || !hassObj.callService) {
    if (!_interceptRetrying) {
      _interceptRetrying = true;
      const timer = setTimeout(() => {
        _interceptRetrying = false;
        interceptCallService();
      }, 500);
      window.GlobalPopupController._retryTimers.push(timer);
    }
    return;
  }

  // 保存原始方法
  if (hassObj._originalCallService) {
    return;
  }

  hassObj._originalCallService = hassObj.callService.bind(hassObj);

  hassObj.callService = function(domain, service, data, target) {
    // 拦截 popup_card 服务
    if (domain === 'popup_card') {

      if (service === 'show' && data && data.card) {
        window.GlobalPopupController.show({
          card: data.card,
          title: data.title || null,
          hide_header: data.hide_header !== undefined ? data.hide_header : true,
          background: data.background || '',
          popup_gap: data.popup_gap,
          popup_width: data.popup_width || null,
          popup_top: data.popup_top || null,
          popup_safe_area: data.popup_safe_area || 'auto'
        });
        return Promise.resolve();
      }

      if (service === 'close') {
        window.GlobalPopupController.close();
        return Promise.resolve();
      }
    }

    // 其他服务调用原始方法
    return hassObj._originalCallService(domain, service, data, target);
  };

};

// 初始化
const init = () => {
  window.GlobalPopupController.init();
  interceptCallService();
  window.GlobalPopupController._startPollTimer();
};

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => setTimeout(init, 500));
} else {
  setTimeout(init, 500);
}

// 监听系统主题变化
if (window.matchMedia) {
  window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', (e) => {
    // 主题变化时更新所有弹窗样式
    window.GlobalPopupController._popupStack.forEach(popupInfo => {
      const isDark = e.matches;
      popupInfo.popup.style.background = isDark ? 'rgba(20, 20, 20, 0.98)' : 'rgba(255, 255, 255, 0.98)';

      // 更新标题和关闭按钮颜色
      const titleEl = popupInfo.popup.querySelector('.popup-card-title');
      if (titleEl) {
        titleEl.style.color = isDark ? 'rgba(255, 255, 255, 0.9)' : '#2c3e50';
      }

      // 更新关闭按钮背景
      const closeBtn = popupInfo.popup.querySelector('button');
      if (closeBtn) {
        closeBtn.style.background = isDark ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.05)';
        closeBtn.style.color = isDark ? 'rgba(255, 255, 255, 0.9)' : '#2c3e50';
      }
    });
  });
}

// 监听页面可见性变化
document.addEventListener('visibilitychange', () => {
  const ctrl = window.GlobalPopupController;

  if (document.visibilityState === 'visible') {
    ctrl._isVisible = true;

    // 页面不可见期间有状态变化，恢复后统一刷新一次
    if (ctrl._staleUpdate && ctrl._popupStack.length > 0) {
      ctrl._staleUpdate = false;
      const haRoot = document.querySelector('home-assistant');
      const newHass = haRoot?.hass || haRoot?.shadowRoot?.querySelector('home-assistant-main')?.hass;
      if (newHass && newHass !== ctrl.hass) {
        ctrl.hass = newHass;
        ctrl._updateAllCards();
      }
    }

    // 恢复服务拦截轮询
    ctrl._startPollTimer();

    // 检查服务拦截状态
    setTimeout(interceptCallService, 1000);
  } else {
    ctrl._isVisible = false;
    // 暂停服务拦截轮询
    ctrl._stopPollTimer();
  }
});

// 添加全局错误处理
window.addEventListener('error', (event) => {
  if (event.message && event.message.includes('popup_card')) {
    console.warn('[popup_card] 检测到全局错误，尝试恢复:', event.message);
    setTimeout(() => {
      try {
        interceptCallService();
      } catch (e) {
        console.error('[popup_card] 恢复失败:', e);
      }
    }, 1000);
  }
});

// 添加样式
const styleSheet = document.createElement('style');
styleSheet.textContent = `
  @keyframes popupFadeIn {
    from { opacity: 0; transform: translate(-50%, -50%) scale(0.95); }
    to { opacity: 1; transform: translate(-50%, -50%) scale(1); }
  }
  .popup-card-popup { animation: popupFadeIn 0.2s ease-out; pointer-events: auto !important; box-sizing: border-box; width: 95vw; }
  .popup-card-popup * { pointer-events: auto !important; box-sizing: border-box; }
  .popup-card-content { pointer-events: auto !important; overscroll-behavior: contain; }
  /* cardBox：hide_header 时是滚动容器，两种模式都承担安全区内边距 */
  .popup-card-box { pointer-events: auto !important; box-sizing: border-box; }
  .popup-card-box > .popup-card-content { min-height: 0; }
  .popup-card-overlay { pointer-events: auto !important; }
  .popup-card-content::-webkit-scrollbar { width: 6px; }
  .popup-card-content::-webkit-scrollbar-track { background: rgba(0,0,0,0.1); border-radius: 3px; }
  .popup-card-content::-webkit-scrollbar-thumb { background: rgba(0,0,0,0.3); border-radius: 3px; }
  .popup-card-content::-webkit-scrollbar-thumb:hover { background: rgba(0,0,0,0.5); }
`;
document.head.appendChild(styleSheet);